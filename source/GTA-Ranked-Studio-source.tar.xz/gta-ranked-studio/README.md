﻿> Version du paquet : **0.3.4**.
> Cette version finalise le diagnostic et la configuration de Whisper : état du moteur, support DTW, détection des périphériques Vulkan et validation du modèle local.
> L'interface est une application web locale servie par FastAPI ; aucun média n'est envoyé vers un service cloud.


# GTA Ranked Studio

Application web locale Windows pour préparer automatiquement des vidéos GTA VI : Shorts verticaux et compilations Best Of. Le projet est conçu pour fonctionner gratuitement, sans API payante et sans envoyer de médias vers un service cloud.

> **Profil matériel configuré :** AMD Radeon RX 9060 XT 16 Go (RDNA 4 / gfx1200). Le projet n'utilise donc ni CUDA ni NVENC.

## 1. Architecture matérielle retenue

| Besoin | Technologie retenue | Solution de secours |
|---|---|---|
| Encodage H.264 | FFmpeg `h264_amf` (AMD) | FFmpeg `libx264` (CPU) |
| Transcription | `whisper.cpp` avec backend Vulkan | `whisper.cpp` CPU |
| LLM local | Ollama avec Vulkan si disponible | Ollama CPU |
| Interface web locale | FastAPI + HTML/CSS/JavaScript | Aucun hébergement ni service cloud |

La documentation FFmpeg décrit le backend AMD AMF pour l'encodage matériel : https://ffmpeg.org/general.html. La documentation de `whisper.cpp` décrit les backends Vulkan multi-constructeurs : https://github.com/ggml-org/whisper.cpp. La documentation Ollama indique que Vulkan fournit un chemin de compatibilité GPU supplémentaire sous Windows et Linux : https://github.com/ollama/ollama/blob/main/docs/gpu.mdx. `studio doctor` vérifiera les capacités réellement disponibles sur la machine au lieu de les supposer.

## 2. Prérequis

**Nécessaires pour lancer la première version du site :**

- Windows 10 ou Windows 11 64 bits.
- Connexion Internet pour la première installation.
- Pilote AMD Software: Adrenalin Edition à jour pour la RX 9060 XT : https://www.amd.com/en/support/downloads/drivers.html/graphics/radeon-rx/radeon-rx-9000-series/amd-radeon-rx-9060-xt.html
- WinGet (App Installer Windows). L'installateur l'utilise pour ajouter Python 3.11 ou FFmpeg uniquement lorsqu'ils sont absents. Si Python 3.11 et FFmpeg sont déjà détectés, aucun des deux n'est retéléchargé.

**À installer dans les milestones IA ultérieurs, pas nécessaire pour le premier démarrage web :**

- Ollama pour Windows : https://ollama.com/download/windows
- Vulkan Runtime fourni par le pilote AMD. Pour compiler `whisper.cpp` depuis les sources, installer également le [Vulkan SDK](https://vulkan.lunarg.com/sdk/home#windows), [CMake](https://cmake.org/download/) et [Visual Studio Build Tools](https://visualstudio.microsoft.com/visual-cpp-build-tools/) avec le workload C++.

Aucune clé API n'est nécessaire. Aucune installation CUDA ou cuDNN n'est nécessaire ni prévue pour cette configuration AMD.

## 3. Installation du projet

Extrais l'archive dans un dossier simple, par exemple `C:\Outils\GTA Ranked Studio`. Double-clique ensuite sur `INSTALL.bat`. L'installateur détecte Python 3.11 et FFmpeg, et utilise WinGet uniquement si l'un des composants manque. Il crée `.venv` au premier lancement. Tu n'as pas besoin de mettre à jour pip manuellement.

```powershell
py -3.11 --version
.\.venv\Scripts\python.exe -m pip check
```

## Mise à jour sans doublons (v0.2.6 et suivantes)

L'installateur est incrémental :

- Il réutilise `.venv` si l'environnement Python 3.11 64 bits est valide.
- Il ne réinstalle pas Python si `py -3.11` le détecte.
- Il ne réinstalle pas FFmpeg si `ffmpeg.exe` et `ffprobe.exe` sont déjà accessibles.
- Si l'empreinte de `requirements.txt` est identique et que les contrôles passent, `pip install` est ignoré.
- Si une dépendance change, pip ne télécharge que les paquets absents ou incompatibles ; il conserve les paquets déjà satisfaits et utilise son cache.
- La mise à jour v0.2.6 reconnaît l'empreinte de v0.2.5 et installe uniquement `httpx2` ainsi que ses éventuelles dépendances manquantes.
- Les clips, la base SQLite, les sorties, les modèles, les journaux, la configuration et les prompts actifs ne sont pas supprimés.

**Mise à jour vers v0.3.2 depuis v0.2.6 ou v0.3.1 :** ferme le site avec `STOP-STUDIO.bat`, extrais l'archive v0.3.2 dans un nouveau dossier temporaire, puis double-clique sur `UPDATE-FROM-ARCHIVE.bat` depuis le dossier extrait. L'assistant retrouve l'installation mémorisée ou te demande le chemin de ton dossier déjà installé. Il sauvegarde le code précédent, remplace uniquement `studio`, `installer` et `tests`, puis met à jour les fichiers de lancement et la documentation. Il conserve `.venv`, `config.yaml`, les prompts actifs, les clips, les rendus, la base SQLite, les modèles, les outils, les journaux et les assets.

Après la première installation réussie, l'emplacement est mémorisé dans `%LOCALAPPDATA%\GTA Ranked Studio\install-location.txt`. Pour les futures mises à jour, réutilise `UPDATE-FROM-ARCHIVE.bat`. Ne relance pas `INSTALL.bat` pour une mise à jour ordinaire. `INSTALL.bat` reste réservé à une première installation ou une réparation volontaire.

## 4. FFmpeg avec accélération AMD

Le moyen le plus simple est d'installer la build complète Windows de Gyan avec WinGet :

```powershell
winget install ffmpeg
```

La page des builds Windows est https://www.gyan.dev/ffmpeg/builds/. Vérifie que le dossier `bin` de FFmpeg est dans le `PATH` Windows, puis ouvre un nouveau terminal. Le projet utilise `h264_amf` en priorité et `libx264` si AMF est indisponible. La présence d'AMF dépend de la build retenue : le diagnostic ci-dessous le vérifiera.

Vérifie les deux exécutables :

```powershell
ffmpeg -version
ffprobe -version
```

Vérifie l'encodeur AMD :

```powershell
ffmpeg -hide_banner -encoders | findstr /i "h264_amf"
```

La commande doit retourner une ligne contenant `h264_amf`. Si elle ne retourne rien, FFmpeg peut toujours fonctionner avec `libx264`, mais l'encodage sera réalisé par le processeur.

Les filtres suivants seront utilisés par les milestones de rendu :

```powershell
ffmpeg -hide_banner -filters | findstr /i "loudnorm ass boxblur"
```

## 5. whisper.cpp avec Vulkan (configuration AMD)

Le projet utilise `whisper.cpp`, et non `faster-whisper` CUDA. Le backend Vulkan permet d'utiliser un GPU AMD sans CUDA.

### Installation recommandée : build Vulkan Windows précompilée

Pour éviter d'installer CMake, Visual Studio Build Tools et le Vulkan SDK sur ton PC, tu peux utiliser une archive Windows x64 précompilée avec Vulkan. Le dépôt `jiang1997/whisper.cpp-release` publie des builds Windows avec Vulkan, basées sur les sources upstream whisper.cpp. Ce n'est pas une distribution officielle du projet upstream : vérifie la provenance de l'archive avant exécution.

1. Ouvre les [releases Windows Vulkan](https://github.com/jiang1997/whisper.cpp-release/releases).
2. Télécharge l'archive Windows x64 de la dernière release.
3. Extrais **tout le contenu** de l'archive dans `tools\whisper.cpp\` (ne copie pas uniquement le `.exe` : les DLL nécessaires doivent rester à côté).
4. Vérifie que `tools\whisper.cpp\whisper-cli.exe` est présent.
5. Dans GTA Ranked Studio, ouvre `Paramètres` puis clique sur `Actualiser`. Le diagnostic vérifie le démarrage du binaire, les options DTW et les périphériques exposés par la build.
6. Télécharge ensuite le modèle large-v3-turbo depuis la même page `Paramètres`.

Le pilote AMD fournit normalement le runtime Vulkan. Le Vulkan SDK et les outils de compilation ne sont pas nécessaires pour exécuter une build déjà compilée.

### Alternative : compilation officielle depuis les sources

Si tu préfères compiler toi-même le moteur, installe CMake, Visual Studio Build Tools 2022 avec le workload C++ et le Vulkan SDK de LunarG. Puis utilise un Developer PowerShell for VS 2022 :

```powershell
git clone https://github.com/ggml-org/whisper.cpp.git tools\whisper.cpp-source
cmake -S tools\whisper.cpp-source -B tools\whisper.cpp-source\build -DGGML_VULKAN=1 -DCMAKE_BUILD_TYPE=Release
cmake --build tools\whisper.cpp-source\build --config Release -j
```

Copie `whisper-cli.exe` **et les DLL générées** dans `tools\whisper.cpp\`. Le modèle reste dans `models\whisper\`.

## 6. Ollama local

Installe Ollama pour Windows, puis ouvre PowerShell :

```powershell
ollama --version
ollama pull qwen2.5:7b-instruct
ollama list
```

L'API locale par défaut écoute sur `http://127.0.0.1:11434`. Le projet lui enverra uniquement les transcriptions et les métadonnées utiles à la génération des textes. Les fichiers vidéo ne seront pas transmis à Ollama.

Point de compatibilité important : la liste ROCm Windows d'Ollama ne cite pas actuellement la RX 9060 XT, alors que sa documentation indique un backend Vulkan supplémentaire sous Windows et Linux. On utilise donc Vulkan comme premier essai, sans présumer que l'offload GPU fonctionnera sur cette configuration précise. Si Ollama ne sélectionne pas le GPU, il doit rester fonctionnel sur CPU. `studio doctor` vérifie l'API locale et la présence du modèle; un test d'inférence GPU sera ajouté dans un milestone ultérieur.

## 7. Premier diagnostic

Depuis la racine du projet, avec l'environnement virtuel activé :

```powershell
studio doctor
```

Le diagnostic crée les dossiers du projet et écrit :

```text
logs\doctor-report.json
logs\studio.log
```

Les avertissements concernant whisper.cpp, le modèle Whisper, Ollama ou les polices peuvent être normaux avant leur installation. L'option stricte retourne un code d'erreur si des composants sont encore manquants :

```powershell
studio doctor --strict
```

Tu peux choisir un autre fichier YAML :

```powershell
studio --config .\config.yaml doctor
```

## 8. Tests

```powershell
pytest -q
```

Les tests actuels vérifient la configuration, les chemins, la base SQLite, les routes web et la construction des commandes FFmpeg. Les tests des sous-titres, du scoring et des chapitres seront ajoutés dans les milestones correspondants.

## 9. Arborescence

```text
gta-ranked-studio/
├── assets/fonts/
├── data/
├── inbox/
│   ├── shorts/
│   ├── bestof/
│   └── urls.txt
├── logs/
├── models/whisper/
├── out/
│   ├── shorts/
│   └── bestof/
├── prompts/
├── studio/
│   ├── web/
│   │   ├── app.py
│   │   ├── store.py
│   │   ├── worker.py
│   │   ├── short_renderer.py
│   │   └── static/
│   ├── cli.py
│   ├── config.py
│   ├── doctor.py
│   └── logging_setup.py
├── tests/
├── tools/whisper.cpp/
├── work/tmp/
├── config.yaml.default  # modèle copié en config.yaml au premier lancement
├── pyproject.toml
└── requirements.txt
```

## 10. Lancer le site web local

Après l'installation, double-clique sur `START-STUDIO.bat` ou sur le raccourci Windows `GTA Ranked Studio` s'il a été créé. Le lanceur démarre le serveur local en arrière-plan et ouvre Chrome sur `http://127.0.0.1:8765`. Pour arrêter le serveur proprement, double-clique sur `STOP-STUDIO.bat`.

Le serveur écoute uniquement sur `127.0.0.1` : il n'est pas exposé sur Internet ni sur le réseau local. Le traitement vidéo, la transcription, les métadonnées, les modèles et les bases de données restent sur le PC. L'import d'une URL nécessite une connexion au site source pour télécharger le média.

### Ce que fait le Short en v0.3.1

- Sortie verticale réelle en **1080 × 1920 (9:16)**. Le mode par défaut recadre la vidéo pour remplir l'écran au lieu de placer une petite vidéo paysage sur un fond flou.
- Mode alternatif `Vidéo entière + fond flouté` pour conserver le cadre source.
- Curseurs de position X/Y pour déplacer le cadrage.
- Détection du pic audio et zoom avant/arrière progressif autour de ce moment. Le zoom est centré sur l'image, pas encore sur le visage.
- Coupe automatique optionnelle des sources de plus de 45 secondes, avec une fenêtre de 15 à 45 secondes autour du moment fort. Si une transcription est disponible, les fins de phrases et pauses peuvent améliorer le point de sortie.
- Hook, carte de contexte, badge GTA VI et handle, gravés dans le rendu.
- Normalisation sonore à -14 LUFS, fondus courts et effet whoosh discret original, activable ou désactivable.
- Miniature verticale avec texte, fichiers `title.txt`, `description.txt`, `meta.json`, `captions.srt` et `captions.ass`.
- Encodage AMD `h264_amf` quand FFmpeg le détecte, avec `libx264` en secours.

### Transcription et captions

Dans `Paramètres`, le modèle `ggml-large-v3-turbo.bin` peut être téléchargé depuis le dépôt public de whisper.cpp (environ 1,62 Go). Il faut également que `whisper-cli.exe` soit disponible dans `tools/whisper.cpp/`. Le diagnostic de la page `Paramètres` distingue maintenant le moteur, le modèle, la disponibilité de DTW et les périphériques Vulkan détectés. Un fichier modèle anormalement petit n'est plus accepté comme installé.

La nouvelle logique ne confond plus `-ml` et les timestamps mot à mot : dans whisper.cpp, `-ml` règle la longueur maximale des segments en caractères. Les vrais timestamps de tokens sont demandés avec `-dtw` et `-ojf` lorsque le binaire les expose. Le studio regroupe ensuite les tokens en mots pour surligner le mot actif. Si le binaire ne fournit pas de timestamps DTW exploitables, il utilise honnêtement le SRT par segments et l'indique dans la file de traitement.

### Métadonnées IA locale

Si Ollama et le modèle `qwen2.5:7b-instruct` sont installés et actifs, le studio leur demande de proposer hook, contexte, titres, description et texte de miniature en anglais. Sans Ollama, des valeurs de secours déterministes sont générées à partir des seules informations disponibles. Il n'y a aucun appel à une API IA cloud.

### Ce qui n'est pas encore livré

Le Daily Best Of complet n'est pas encore actif : le scoring multi-critères, l'interface de sélection/réordonnancement, l'assemblage horizontal 16:9, les chapitres, le Hall of Fame et la miniature du Best Of restent à développer. Le watch folder permanent et l'export CSV des métriques ne sont pas encore finalisés non plus. Aucune publication automatique n'est effectuée.

## 11. État des milestones

- M0 : socle local, configuration, diagnostic et installateur incrémental.
- M1 : rendu Short vertical avec FFmpeg, AMF et fallback CPU.
- M2 : transcription locale et captions ; mot à mot si DTW est pris en charge, sinon par segments.
- M3 : génération des métadonnées avec Ollama local et fallback déterministe.
- M4 : détection du pic audio, coupe automatique, hook, contexte, branding, zoom dynamique et sound design léger.
- M5 : import de fichiers et URL dans la file, hash anti-doublon et Clip Bank après validation. Le watch folder et le CSV restent à compléter.
- M6 : scoring audio, parole, activité visuelle et classement. À développer.
- M7 : interface de review Best Of, inclusion/exclusion, trim et réordonnancement. À développer.
- M8 : assemblage Daily Best Of, chapitres, Hall of Fame et miniature. À développer.
- M9 : packaging final et tests sur plusieurs configurations Windows/AMD. En cours.

## Confidentialité et traitement des médias

La version actuelle ne publie rien automatiquement. Les vidéos, métadonnées, caches et rendus restent dans les dossiers locaux du projet. L'import par URL contacte nécessairement le site source pour télécharger le clip, mais le fichier est ensuite traité localement et n'est pas envoyé vers un service cloud. `yt-dlp` ne sera utilisé qu'à la demande pour les URL saisies par l'utilisateur. Respecte les droits et autorisations applicables aux clips importés.


### Correctif v0.3.1
Les tests de transcription utilisent des wrappers `.py` lancés via l'interpréteur courant. Cela évite `WinError 193` sous Windows, qui ne peut pas exécuter un script Python sans association d'exécutable. Un véritable `whisper-cli.exe` natif reste lancé directement.
\n\n## v0.3.3\n\nCorrectif des captions : les groupes de mots trop longs sont automatiquement répartis sur deux lignes dans le format vertical, tout en conservant le surlignage mot à mot.\n
Correctif v0.3.3.1 : fiabilisation de la lecture de VERSION.txt par l'assistant de mise à jour Windows.\n

## v0.3.3.3

Ajout de l'action « Recréer ce Short » pour relancer un rendu à partir du fichier source local d'un job existant, sans nouvel import ni téléchargement.


## v0.3.4 : mises à jour intégrées

Le logiciel peut vérifier les Releases publiques du dépôt GitHub `Sreleew/GTA_rankd` depuis Paramètres > Mises à jour. Lorsqu'une version stable est disponible, l'application télécharge le paquet et son fichier de sommes SHA-256, vérifie l'intégrité, ferme le serveur local puis lance l'installateur PowerShell externe.

L'installateur sauvegarde les dossiers applicatifs avant remplacement. Il conserve `config.yaml`, `.venv`, les bases SQLite, les vidéos sources, les rendus, les journaux, les modèles Whisper/Ollama, les outils locaux et les prompts actifs. En cas d'échec pendant le remplacement, il tente de restaurer la version précédente.

### Publier une nouvelle version

1. Mettre à jour `VERSION.txt` et `pyproject.toml` avec le même numéro.
2. Mettre à jour les notes de version `NOTES-vX.Y.Z.txt`.
3. Pousser les changements sur `main`.
4. Créer un tag `vX.Y.Z` ou lancer manuellement l'action GitHub Actions **Build and publish GTA Ranked Studio** en donnant la version de `VERSION.txt`.
5. GitHub Actions fabrique `GTA-Ranked-Studio-vX.Y.Z.zip`, génère `SHA256SUMS.txt`, puis publie les deux fichiers comme assets d'une Release stable.

La première version intégrant le mécanisme (v0.3.4) doit être installée une fois avec le mécanisme de mise à jour existant. Après ce bootstrap, les versions suivantes s'installeront depuis le bouton de cette page Paramètres.
