# Vérifications v0.3.2

## Whisper

- Le diagnostic distingue moteur absent, moteur exécutable, DTW et périphériques Vulkan listés.
- Le diagnostic est mis en cache 30 secondes afin de ne pas relancer le binaire à chaque rafraîchissement UI.
- Le modèle n'est marqué valide que si le fichier dépasse le seuil minimal de 1 Gio configuré.
- Un modèle existant invalide est supprimé au démarrage d'un nouveau téléchargement afin d'éviter de le conserver comme prêt.
- L'interface distingue l'installation du moteur et celle du modèle.

## Tests

- Tests de parsing DTW et fallback SRT conservés.
- Tests du diagnostic Whisper avec un exécutable simulé.
- Tests du statut de validité du modèle.
- Tests complets : voir résultat pytest dans le dossier de livraison.

## Limites

- Le moteur Vulkan précompilé n'est pas inclus dans l'archive. L'utilisateur doit le télécharger depuis la page documentée ou compiler whisper.cpp lui-même.
- La présence de Vulkan est affichée uniquement si la commande de listing des périphériques est prise en charge par le binaire.
- Le test réel de transcription dépend de la présence du binaire Windows, de ses DLL, du modèle et du pilote Vulkan sur le PC cible.
