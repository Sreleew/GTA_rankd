# Vérification GTA Ranked Studio v0.2.6

## Corrections
- La sortie du contrôle runtime est forcée en UTF-8 et inclut un marqueur de succès ASCII.
- `httpx2` est déclaré comme client préféré pour le `TestClient` de Starlette récent ; `httpx` reste disponible pour compatibilité.
- L'installateur détecte l'empreinte de dépendances v0.2.5 et effectue une migration incrémentale.
- `UPDATE-FROM-ARCHIVE.bat` vérifie les scripts PowerShell avant de remplacer le code, puis conserve `.venv`, `config.yaml`, les prompts actifs et les données locales.

## Vérifications locales
Les tests automatisés sont exécutés dans l'environnement de construction : **34 réussis, 1 ignoré**. Le contrôle de sortie simule `PYTHONIOENCODING=cp1252` pour reproduire le cas Windows. Le test ignoré est celui qui lance le vrai parseur Windows PowerShell, absent de l'environnement de construction.

**Limite de validation :** l'installateur complet et l'encodeur AMD AMF ne peuvent pas être exécutés sur le PC Windows de l'utilisateur depuis cet environnement. Le contrôle PowerShell dédié est automatiquement ignoré lorsque PowerShell Windows n'est pas présent.
