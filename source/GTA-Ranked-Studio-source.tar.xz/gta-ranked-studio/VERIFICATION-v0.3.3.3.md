# Vérification v0.3.3.3

## Recréation d'un Short
L'API `POST /api/jobs/{job_id}/reprocess` vérifie l'existence du job et du fichier source local, puis crée un nouveau job à partir du même média et des mêmes options. Le hash n'est pas copié afin de ne pas déclencher l'index unique de déduplication. Le média original n'est ni copié ni retéléchargé.

## Interface
Les jobs validés, en erreur ou rejetés affichent une action de recréation.

## Validation
Tests automatisés Python exécutés sur l'environnement disponible. La validation du flux complet avec FFmpeg, Whisper et le navigateur doit être faite sur Windows.
