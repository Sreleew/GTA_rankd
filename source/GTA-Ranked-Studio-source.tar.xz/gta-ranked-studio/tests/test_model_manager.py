from pathlib import Path

from studio.web.model_manager import ModelManager


def test_model_manager_does_not_mark_tiny_invalid_file_as_installed(tmp_path: Path):
    model = tmp_path / "ggml-large-v3-turbo.bin"
    model.write_bytes(b"not a real whisper model")

    manager = ModelManager(model)
    status = manager.status()

    assert status["exists"] is True
    assert status["valid"] is False
    assert status["status"] == "invalid"


def test_model_manager_marks_full_size_model_as_installed(tmp_path: Path):
    model = tmp_path / "ggml-large-v3-turbo.bin"
    with model.open("wb") as stream:
        stream.truncate(1024 * 1024 * 1024)

    manager = ModelManager(model)
    status = manager.status()

    assert status["exists"] is True
    assert status["valid"] is True
    assert status["status"] == "ready"
