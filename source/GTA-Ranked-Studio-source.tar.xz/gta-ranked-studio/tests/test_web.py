from pathlib import Path

from fastapi.testclient import TestClient

from studio.config import load_config
from studio.web.app import create_app, safe_upload_name
from studio.web.short_renderer import build_filter_complex, build_render_command
from studio.web.app import _validate_edit_options
from studio.web.store import Store


def test_safe_upload_name_rejects_unsupported_extensions():
    assert safe_upload_name(r"C:\\fake path\\GTA moment.MP4") == "GTA_moment.mp4"
    try:
        safe_upload_name("document.pdf")
    except Exception as exc:
        assert "Format non pris en charge" in str(exc)
    else:
        raise AssertionError("A PDF should be rejected")


def test_default_vertical_filter_fills_the_9_16_frame():
    graph = build_filter_complex(1080, 1920)
    assert "scale=1080:1920:force_original_aspect_ratio=increase" in graph
    assert "crop=1080:1920" in graph
    assert "boxblur" not in graph
    assert "zoompan" in graph


def test_blur_layout_keeps_the_full_landscape_source_visible():
    graph = build_filter_complex(1080, 1920, layout="blur", dynamic_zoom=False)
    assert "boxblur" in graph
    assert "overlay=(W-w)/2:(H-h)/2" in graph


def test_edit_options_are_validated_and_clamped_by_api():
    options = _validate_edit_options("fill", 50, 40, True, 8, True, True, "Wait for it", "A chase", True)
    assert options["layout"] == "fill"
    assert options["crop_x"] == 50
    assert options["dynamic_zoom"] is True
    assert options["auto_trim_enabled"] is True
    try:
        _validate_edit_options("invalid", 50, 50, True, 8, True, True, "", "")
    except Exception as exc:
        assert "cadrage" in str(exc).lower()
    else:
        raise AssertionError("Invalid layout should be rejected")


def test_render_command_uses_argument_list_and_amf(tmp_path: Path):
    # On teste la construction sans lancer FFmpeg sur cette machine de test.
    command = build_render_command(
        "ffmpeg", tmp_path / "input.mp4", tmp_path / "output.mp4", encoder="h264_amf", has_audio=True,
        trim_start=4.5, trim_duration=24.0,
    )
    assert isinstance(command, list)
    assert "h264_amf" in command
    assert any(part.startswith("loudnorm=I=-14:TP=-1.5:LRA=11") for part in command)
    assert "-filter_complex" in command
    assert command[command.index("-ss") + 1] == "4.500"
    assert command[command.index("-t") + 1] == "24.000"


def test_store_creates_and_updates_job(tmp_path: Path):
    store = Store(tmp_path / "test.sqlite")
    store.create_job({"id": "job1", "source_kind": "upload", "source_path": "clip.mp4"})
    job = store.get_job("job1")
    assert job is not None
    assert job["status"] == "queued"
    store.update_job("job1", status="ready", progress=100, message="Prêt")
    updated = store.get_job("job1")
    assert updated["status"] == "ready"
    assert store.get_dashboard()["to_review"] == 1


def test_api_health_and_upload_acknowledgement(tmp_path: Path):
    source_root = Path(__file__).resolve().parents[1]
    config_text = (source_root / "config.yaml").read_text(encoding="utf-8")
    config_path = tmp_path / "config.yaml"
    config_path.write_text(config_text.replace("database: data/clip_bank.sqlite", f"database: {tmp_path.as_posix()}/clip_bank.sqlite")
                                  .replace("inbox_shorts: inbox/shorts", f"inbox_shorts: {tmp_path.as_posix()}/inbox")
                                  .replace("output_shorts: out/shorts", f"output_shorts: {tmp_path.as_posix()}/out/shorts")
                                  .replace("output_bestof: out/bestof", f"output_bestof: {tmp_path.as_posix()}/out/bestof")
                                  .replace("logs: logs", f"logs: {tmp_path.as_posix()}/logs")
                                  .replace("temp: work/tmp", f"temp: {tmp_path.as_posix()}/tmp")
                                  .replace("fonts: assets/fonts", f"fonts: {tmp_path.as_posix()}/fonts")
                                  .replace("prompts: prompts", f"prompts: {tmp_path.as_posix()}/prompts")
                                  .replace("models: models/whisper", f"models: {tmp_path.as_posix()}/models")
                                  .replace("tools: tools", f"tools: {tmp_path.as_posix()}/tools"), encoding="utf-8")
    config = load_config(config_path)
    app = create_app(config)
    client = TestClient(app)
    health = client.get("/api/health")
    assert health.status_code == 200
    assert health.json()["local_only"] is True
    model_status = client.get("/api/models/status?refresh=true")
    assert model_status.status_code == 200
    assert "whisper_diagnostic" in model_status.json()
    assert model_status.json()["whisper_diagnostic"]["available"] is False
    rejected = client.post("/api/shorts/upload", files={"file": ("clip.mp4", b"not real video", "video/mp4")}, data={"rights_confirmed": "false"})
    assert rejected.status_code == 400


def test_clip_enters_library_only_after_atomic_validation(tmp_path: Path):
    store = Store(tmp_path / "validation.sqlite")
    store.create_job({
        "id": "approved-job",
        "source_kind": "upload",
        "source_path": str(tmp_path / "source.mp4"),
        "source_hash": "abc123",
        "streamer": "ExampleStreamer",
    })
    store.update_job(
        "approved-job",
        status="ready",
        progress=100,
        duration=12.5,
        output_path=str(tmp_path / "render.mp4"),
        thumbnail_path=str(tmp_path / "thumbnail.jpg"),
    )

    assert store.list_clips() == []
    validated = store.validate_job_and_add_to_clip_bank("approved-job")
    assert validated is not None
    assert validated["status"] == "validated"
    clips = store.list_clips()
    assert len(clips) == 1
    assert clips[0]["job_id"] == "approved-job"
    assert clips[0]["status"] == "validated"
    assert store.validate_job_and_add_to_clip_bank("approved-job") is None


def test_dynamic_zoom_is_a_smooth_punch_in_not_a_hard_step():
    graph = build_filter_complex(1080, 1920, dynamic_zoom=True, peak_timestamp=4.0, zoom_percent=10)
    assert "sin(PI*(in_time-3.550)/1.300)" in graph
    assert "(0.100)" in graph


def test_render_command_mixes_optional_original_whoosh(tmp_path: Path):
    sfx = tmp_path / "whoosh.wav"
    sfx.write_bytes(b"fake-wav-for-command-builder")
    command = build_render_command(
        "ffmpeg", tmp_path / "input.mp4", tmp_path / "output.mp4",
        encoder="libx264", has_audio=True, sound_effect_path=sfx, sound_effect_offset=2.35,
    )
    graph = command[command.index("-filter_complex") + 1]
    assert str(sfx.resolve()) in command
    assert "adelay=2350:all=1" in graph
    assert "amix=inputs=2" in graph
    assert command[command.index("-map", command.index("-filter_complex")) + 1] == "[v]"
