from studio.web.metadata import generate_short_metadata


def test_metadata_fallback_is_bounded_and_credits_source():
    result = generate_short_metadata(
        streamer="StreamerA", note="The police chase went wrong", source_url="https://example.test/clip",
        custom_hook="THIS IS A VERY LONG HOOK WITH WAY MORE THAN EIGHT WORDS INCLUDED",
        custom_context="One two three four five six seven eight nine ten eleven twelve",
        ollama_base_url="http://127.0.0.1:1", retries=0,
    )
    assert len(result["hook_text"].split()) <= 8
    assert len(result["context_card"].split()) <= 10
    assert "Clip: StreamerA (https://example.test/clip)" in result["description"]
    assert result["generator"] == "local_fallback"


def test_custom_hook_and_context_override_fallback() -> None:
    metadata = generate_short_metadata(
        streamer="Streamer", custom_hook="THIS IS THE MOMENT TO WATCH",
        custom_context="Police chase near Vice City",
        ollama_base_url="http://127.0.0.1:1", retries=0, timeout=1,
    )
    assert metadata["hook_text"] == "THIS IS THE MOMENT TO WATCH"
    assert metadata["context_card"] == "Police chase near Vice City"
