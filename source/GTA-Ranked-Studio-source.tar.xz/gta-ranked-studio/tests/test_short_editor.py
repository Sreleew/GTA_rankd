from pathlib import Path

from studio.web.short_editor import (
    WordTiming, apply_thumbnail_overlay, create_ass_file, parse_srt,
    rebase_word_timings, select_excerpt_range, write_srt_file,
)


def test_parse_srt_word_timestamps(tmp_path: Path):
    srt = tmp_path / "captions.srt"
    srt.write_text(
        "1\n00:00:00,120 --> 00:00:00,420\nBro\n\n"
        "2\n00:00:00,430 --> 00:00:00,700\nwhat\n\n"
        "3\n00:00:00,710 --> 00:00:01,000\nHAPPENED?\n",
        encoding="utf-8",
    )
    words = parse_srt(srt)
    assert [word.text for word in words] == ["Bro", "what", "HAPPENED?"]
    assert words[0].start == 0.12
    assert words[-1].end == 1.0


def test_ass_contains_hook_branding_and_active_word_highlight(tmp_path: Path):
    path = create_ass_file(
        tmp_path / "captions.ass",
        words=[WordTiming(0.1, 0.3, "Bro"), WordTiming(0.3, 0.6, "WHAT"), WordTiming(0.6, 0.9, "HAPPENED?")],
        hook_text="BRO THOUGHT HE WAS SAFE",
        context_text="A GTA VI police chase goes wrong",
        handle="@GTARankedStudio",
        brand_enabled=True,
    )
    content = path.read_text(encoding="utf-8-sig")
    assert "BRO THOUGHT HE WAS SAFE" in content
    assert "@GTARankedStudio" in content
    assert "GTA VI" in content
    assert "HAPPENED?" in content
    assert r"\c&H0000C8F5&" in content


def test_ass_can_disable_captions_and_brand(tmp_path: Path):
    path = create_ass_file(
        tmp_path / "minimal.ass", words=[WordTiming(0, 0.3, "HELLO")],
        captions_enabled=False, brand_enabled=False,
    )
    content = path.read_text(encoding="utf-8-sig")
    assert "HELLO" not in content
    assert "@GTARankedStudio" not in content


def test_thumbnail_overlay_adds_editorial_text(tmp_path: Path) -> None:
    from PIL import Image, ImageChops

    thumbnail = tmp_path / "thumbnail.jpg"
    Image.new("RGB", (360, 640), (30, 40, 55)).save(thumbnail, quality=90)
    with Image.open(thumbnail) as original:
        baseline = original.convert("RGB").copy()
    apply_thumbnail_overlay(thumbnail, "GTA VI CRAZY MOMENT")
    with Image.open(thumbnail) as result:
        assert result.size == (360, 640)
        assert result.format == "JPEG"
        assert ImageChops.difference(baseline, result.convert("RGB")).getbbox() is not None
        assert thumbnail.stat().st_size > 1000


def test_long_clip_excerpt_keeps_payoff_and_context() -> None:
    words = [
        WordTiming(25.0, 25.3, "Wait"),
        WordTiming(25.35, 25.7, "for"),
        WordTiming(25.75, 26.1, "it."),
        WordTiming(29.0, 29.4, "What"),
        WordTiming(29.45, 30.0, "happened?"),
    ]
    start, end = select_excerpt_range(60.0, 29.2, words)
    assert 0 <= start < 29.2 < end <= 60
    assert 15 <= end - start <= 45
    assert end >= 32.0  # environ 2 secondes après la fin de la réaction


def test_short_clip_is_never_trimmed_and_word_times_are_rebased(tmp_path: Path) -> None:
    assert select_excerpt_range(21.1, 10.0, []) == (0.0, 21.1)
    original = [WordTiming(10.0, 10.3, "Bro"), WordTiming(10.35, 10.8, "WHAT?")]
    rebased = rebase_word_timings(original, 9.0, 11.0)
    assert rebased == [WordTiming(1.0, 1.3, "Bro"), WordTiming(1.35, 1.8, "WHAT?")]
    path = write_srt_file(tmp_path / "captions.srt", rebased)
    contents = path.read_text(encoding="utf-8")
    assert "00:00:01,000 --> 00:00:01,300" in contents
    assert "WHAT?" in contents


def test_long_caption_segment_is_split_and_wrapped_for_vertical_safe_area(tmp_path: Path):
    words = [WordTiming(0.0, 1.2, "SHOOT IF I'M CLOSE TO CIVILIANS, THEY")]
    path = create_ass_file(tmp_path / "wrapped.ass", words=words, brand_enabled=False)
    content = path.read_text(encoding="utf-8-sig")
    assert r"\N" in content
    assert "CIVILIANS" in content
    # A segment-level fallback is expanded to individual active words.
    assert content.count("Dialogue: 0,") > 1
