from pathlib import Path

from studio.web.transcribe import (
    detect_audio_peak_timestamp, parse_whisper_json_words, transcribe_with_whisper_cpp,
)


def test_transcriber_reports_missing_model_without_crashing(tmp_path: Path):
    result = transcribe_with_whisper_cpp(
        tmp_path / "audio.wav", whisper_cli="missing-whisper-cli.exe",
        model_path=tmp_path / "missing-model.bin", output_dir=tmp_path / "out",
    )
    assert result["status"] == "unavailable"
    assert result["words"] == []


def test_peak_detector_returns_zero_for_missing_wav(tmp_path: Path):
    assert detect_audio_peak_timestamp(tmp_path / "missing.wav") == 0.0


def test_whisper_json_dtw_tokens_are_grouped_into_word_timings(tmp_path: Path):
    payload = {
        "transcription": [
            {
                "timestamps": {"from": "00:00:00.000", "to": "00:00:02.000"},
                "tokens": [
                    {"text": " Hello", "t_dtw": 12},
                    {"text": " there", "t_dtw": 55},
                    {"text": "!", "t_dtw": 82},
                ],
            }
        ]
    }
    path = tmp_path / "transcript.json"
    import json
    path.write_text(json.dumps(payload), encoding="utf-8")
    words = parse_whisper_json_words(path)
    assert [word.text for word in words] == ["Hello", "there!"]
    assert words[0].start == 0.12
    assert words[0].end == 0.55
    assert words[1].start == 0.55
    assert words[1].end == 2.0


def test_whisper_json_rejects_non_dtw_zero_timestamps(tmp_path: Path):
    import json
    path = tmp_path / "transcript.json"
    path.write_text(json.dumps({"transcription": [{
        "timestamps": {"from": "00:00:00.000", "to": "00:00:01.000"},
        "tokens": [{"text": " Hello", "t_dtw": 0}, {"text": " world", "t_dtw": 0}],
    }]}), encoding="utf-8")
    assert parse_whisper_json_words(path) == []


def test_whisper_cli_requests_dtw_full_json_for_word_timestamps(tmp_path: Path):
    import json
    import os
    import sys
    import textwrap

    binary = tmp_path / "fake-whisper.py"
    binary.write_text(textwrap.dedent(f"""\
        #!{sys.executable}
        import json, pathlib, sys
        if '--help' in sys.argv:
            print('-dtw MODEL --dtw MODEL')
            print('-ojf --output-json-full')
            raise SystemExit(0)
        args = sys.argv[1:]
        base = pathlib.Path(args[args.index('-of') + 1])
        base.with_suffix('.srt').write_text('1\\n00:00:00,000 --> 00:00:01,000\\nHello there!\\n', encoding='utf-8')
        payload = {{'transcription': [{{
            'timestamps': {{'from': '00:00:00.000', 'to': '00:00:01.000'}},
            'tokens': [{{'text': ' Hello', 't_dtw': 12}}, {{'text': ' there', 't_dtw': 55}}, {{'text': '!', 't_dtw': 82}}]
        }}]}}
        base.with_suffix('.json').write_text(json.dumps(payload), encoding='utf-8')
        if '-dtw' not in args or '-ojf' not in args:
            raise SystemExit(4)
        raise SystemExit(0)
    """), encoding="utf-8")
    binary.chmod(0o755)
    model = tmp_path / "model.bin"
    model.write_bytes(b"model")
    audio = tmp_path / "audio.wav"
    audio.write_bytes(b"audio")

    result = transcribe_with_whisper_cpp(
        audio, whisper_cli=binary, model_path=model, output_dir=tmp_path / "out"
    )

    assert result["status"] == "completed"
    assert result["timestamp_mode"] == "word_dtw"
    assert [word.text for word in result["words"]] == ["Hello", "there!"]


def test_whisper_cli_falls_back_to_srt_when_dtw_is_unavailable(tmp_path: Path):
    import sys
    import textwrap

    binary = tmp_path / "fake-whisper-no-dtw.py"
    binary.write_text(textwrap.dedent(f"""\
        #!{sys.executable}
        import pathlib, sys
        if '--help' in sys.argv:
            print('-osrt --output-srt')
            raise SystemExit(0)
        args = sys.argv[1:]
        base = pathlib.Path(args[args.index('-of') + 1])
        base.with_suffix('.srt').write_text('1\\n00:00:00,000 --> 00:00:01,000\\nHello there!\\n', encoding='utf-8')
        if '-dtw' in args or '-ojf' in args:
            raise SystemExit(4)
        raise SystemExit(0)
    """), encoding="utf-8")
    binary.chmod(0o755)
    model = tmp_path / "model.bin"
    model.write_bytes(b"model")
    audio = tmp_path / "audio.wav"
    audio.write_bytes(b"audio")

    result = transcribe_with_whisper_cpp(
        audio, whisper_cli=binary, model_path=model, output_dir=tmp_path / "out"
    )

    assert result["status"] == "completed_segment_fallback"
    assert result["timestamp_mode"] == "segment_srt"
    assert result["words"][0].text == "Hello there!"


def test_inspect_whisper_cli_reports_dtw_and_vulkan_devices(tmp_path: Path):
    import sys
    import textwrap
    from studio.web.transcribe import inspect_whisper_cli

    binary = tmp_path / "fake-whisper.py"
    binary.write_text(textwrap.dedent(f"""\
        #!{sys.executable}
        import sys
        if '--help' in sys.argv:
            print('whisper.cpp 1.8.4')
            print('-dtw --dtw-model -ojf --output-json-full --list-devices')
        elif '--list-devices' in sys.argv:
            print('Vulkan0: AMD Radeon RX 9060 XT')
        raise SystemExit(0)
    """), encoding="utf-8")
    binary.chmod(0o755)

    result = inspect_whisper_cli(binary)

    assert result["available"] is True
    assert result["version"] == "1.8.4"
    assert result["dtw_supported"] is True
    assert result["device_listing_supported"] is True
    assert result["vulkan_detected"] is True
    assert "AMD Radeon RX 9060 XT" in result["devices"][0]


def test_inspect_whisper_cli_reports_missing_binary(tmp_path: Path):
    from studio.web.transcribe import inspect_whisper_cli

    result = inspect_whisper_cli(tmp_path / "missing-whisper-cli.exe")
    assert result["available"] is False
    assert "introuvable" in result["message"]
