﻿#requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$ProjectRoot,
    [Parameter(Mandatory=$true)][string]$ArchivePath,
    [Parameter(Mandatory=$true)][string]$ExpectedVersion,
    [Parameter(Mandatory=$true)][int]$ParentPid,
    [Parameter(Mandatory=$true)][string]$LogPath
)

$ErrorActionPreference = 'Stop'
$ProjectRoot = [System.IO.Path]::GetFullPath($ProjectRoot)
$ArchivePath = [System.IO.Path]::GetFullPath($ArchivePath)
$LogPath = [System.IO.Path]::GetFullPath($LogPath)
$backupRoot = $null
$stagingRoot = $null
$backedDirectories = New-Object 'System.Collections.Generic.List[string]'
$backedFiles = New-Object 'System.Collections.Generic.List[string]'
$replacedDirectories = New-Object 'System.Collections.Generic.List[string]'
$replacedFiles = New-Object 'System.Collections.Generic.List[string]'
$rootFiles = @(
    'INSTALL.bat', 'UPDATE-FROM-ARCHIVE.bat', 'REPAIR.bat',
    'START-STUDIO.bat', 'START-STUDIO.vbs', 'STOP-STUDIO.bat',
    'pyproject.toml', 'requirements.txt', '.gitignore', 'README.md', 'README_M0.txt',
    'GUIDE_INSTALLATION_FR.md', 'LIRE-MOI-DABORD.txt', 'config.yaml.default',
    'VERSION.txt', 'NOTES-v0.3.4.txt', 'VERIFICATION-v0.3.4.md'
)

function Write-UpdateLog([string]$Message) {
    $line = '[{0}] {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message
    $parent = Split-Path -Parent $LogPath
    New-Item -ItemType Directory -Path $parent -Force | Out-Null
    Add-Content -LiteralPath $LogPath -Value $line -Encoding UTF8
}

function Get-PackageVersion([string]$Folder) {
    $versionFile = Join-Path $Folder 'VERSION.txt'
    if (-not (Test-Path -LiteralPath $versionFile -PathType Leaf)) {
        throw "VERSION.txt absent du paquet : $versionFile"
    }
    $text = [System.IO.File]::ReadAllText($versionFile, [System.Text.Encoding]::UTF8).TrimStart([char]0xFEFF)
    $match = [regex]::Match($text, '(?im)^\s*Version\s*:\s*(\d+(?:\.\d+){2,3})\s*$')
    if (-not $match.Success) { throw 'Le numéro de version du paquet est illisible.' }
    return $match.Groups[1].Value
}

function Copy-DirectoryContent([string]$Source, [string]$Destination) {
    New-Item -ItemType Directory -Path $Destination -Force | Out-Null
    Get-ChildItem -LiteralPath $Source -Force | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination $Destination -Recurse -Force
    }
}

try {
    Write-UpdateLog 'Démarrage de l’installation de mise à jour.'
    if (-not (Test-Path -LiteralPath $ProjectRoot -PathType Container)) { throw "Installation introuvable : $ProjectRoot" }
    if (-not (Test-Path -LiteralPath $ArchivePath -PathType Leaf)) { throw "Archive de mise à jour introuvable : $ArchivePath" }
    if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot 'config.yaml') -PathType Leaf)) { throw 'config.yaml est absent : ce dossier ne semble pas être une installation GTA Ranked Studio.' }

    # L'application prépare ce processus, puis ferme son serveur et son lanceur.
    $deadline = (Get-Date).AddSeconds(90)
    while (Get-Process -Id $ParentPid -ErrorAction SilentlyContinue) {
        if ((Get-Date) -gt $deadline) { throw 'GTA Ranked Studio ne s’est pas fermé dans le délai prévu. Aucun fichier n’a été remplacé.' }
        Start-Sleep -Milliseconds 400
    }

    $stagingRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("GTA-Ranked-Studio-update-" + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $stagingRoot -Force | Out-Null
    Expand-Archive -LiteralPath $ArchivePath -DestinationPath $stagingRoot -Force
    $packageRoot = Join-Path $stagingRoot 'gta-ranked-studio'
    if (-not (Test-Path -LiteralPath $packageRoot -PathType Container)) { throw 'Structure du paquet invalide : dossier gta-ranked-studio absent.' }
    $packageVersion = Get-PackageVersion $packageRoot
    if ($packageVersion -ne $ExpectedVersion) { throw "Version attendue $ExpectedVersion, version du paquet $packageVersion." }

    foreach ($directoryName in @('studio', 'installer', 'tests')) {
        if (-not (Test-Path -LiteralPath (Join-Path $packageRoot $directoryName) -PathType Container)) {
            throw "Le paquet est incomplet : dossier $directoryName absent."
        }
    }

    $backupRoot = Join-Path $ProjectRoot ("work\updates\rollback-{0}-to-{1}" -f (Get-Date -Format 'yyyyMMdd-HHmmss'), $packageVersion)
    New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null

    Write-UpdateLog 'Sauvegarde des fichiers applicatifs.'
    foreach ($directoryName in @('studio', 'installer', 'tests')) {
        $target = Join-Path $ProjectRoot $directoryName
        if (Test-Path -LiteralPath $target -PathType Container) {
            Copy-Item -LiteralPath $target -Destination $backupRoot -Recurse -Force
            [void]$backedDirectories.Add($directoryName)
        }
    }
    foreach ($fileName in $rootFiles) {
        $target = Join-Path $ProjectRoot $fileName
        if (Test-Path -LiteralPath $target -PathType Leaf) {
            Copy-Item -LiteralPath $target -Destination $backupRoot -Force
            [void]$backedFiles.Add($fileName)
        }
    }

    Write-UpdateLog 'Installation des nouveaux fichiers applicatifs.'
    foreach ($directoryName in @('studio', 'installer', 'tests')) {
        $target = Join-Path $ProjectRoot $directoryName
        [void]$replacedDirectories.Add($directoryName)
        if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Recurse -Force }
        Copy-Item -LiteralPath (Join-Path $packageRoot $directoryName) -Destination $ProjectRoot -Recurse -Force
    }
    foreach ($fileName in $rootFiles) {
        $source = Join-Path $packageRoot $fileName
        if (Test-Path -LiteralPath $source -PathType Leaf) {
            [void]$replacedFiles.Add($fileName)
            Copy-Item -LiteralPath $source -Destination (Join-Path $ProjectRoot $fileName) -Force
        }
    }

    # Les dépendances déjà satisfaites restent en place. pip ne récupère que les paquets
    # manquants ou incompatibles, en réutilisant son cache local.
    $venvPython = Join-Path $ProjectRoot '.venv\Scripts\python.exe'
    $requirementsFile = Join-Path $ProjectRoot 'requirements.txt'
    if ((Test-Path -LiteralPath $venvPython -PathType Leaf) -and (Test-Path -LiteralPath $requirementsFile -PathType Leaf)) {
        Write-UpdateLog 'Vérification des dépendances Python.'
        & $venvPython -m pip install --disable-pip-version-check -r $requirementsFile
        if ($LASTEXITCODE -ne 0) { throw 'La mise à jour des dépendances Python a échoué.' }
    }

    # Mettre à jour les prompts par défaut sans écraser les prompts personnalisés.
    $sourcePrompts = Join-Path $packageRoot 'prompts'
    $targetPrompts = Join-Path $ProjectRoot 'prompts'
    New-Item -ItemType Directory -Path $targetPrompts -Force | Out-Null
    if (Test-Path -LiteralPath $sourcePrompts -PathType Container) {
        Get-ChildItem -LiteralPath $sourcePrompts -Filter '*.default.txt' -File | ForEach-Object {
            Copy-Item -LiteralPath $_.FullName -Destination $targetPrompts -Force
        }
    }

    # Ajouter l'effet fourni par l'application seulement s'il n'existe pas déjà.
    $sourceWhoosh = Join-Path $packageRoot 'assets\sfx\soft_whoosh.wav'
    $targetWhoosh = Join-Path $ProjectRoot 'assets\sfx\soft_whoosh.wav'
    if ((Test-Path -LiteralPath $sourceWhoosh -PathType Leaf) -and -not (Test-Path -LiteralPath $targetWhoosh)) {
        New-Item -ItemType Directory -Path (Split-Path -Parent $targetWhoosh) -Force | Out-Null
        Copy-Item -LiteralPath $sourceWhoosh -Destination $targetWhoosh
    }

    $installedVersion = Get-PackageVersion $ProjectRoot
    if ($installedVersion -ne $ExpectedVersion) { throw "Contrôle final échoué : version installée $installedVersion." }
    Write-UpdateLog "Mise à jour vers $installedVersion réussie."
    Write-Host "Mise à jour vers $installedVersion terminée." -ForegroundColor Green
    Start-Sleep -Seconds 1
    $launcher = Join-Path $ProjectRoot 'START-STUDIO.bat'
    if (Test-Path -LiteralPath $launcher -PathType Leaf) {
        Start-Process -FilePath $launcher -WorkingDirectory $ProjectRoot
    }
}
catch {
    $message = $_.Exception.Message
    Write-UpdateLog "ERREUR : $message"
    Write-UpdateLog 'Tentative de restauration de la version précédente.'
    try {
        foreach ($directoryName in $replacedDirectories) {
            $target = Join-Path $ProjectRoot $directoryName
            if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Recurse -Force }
            if ($backedDirectories.Contains($directoryName)) {
                Copy-Item -LiteralPath (Join-Path $backupRoot $directoryName) -Destination $ProjectRoot -Recurse -Force
            }
        }
        foreach ($fileName in $replacedFiles) {
            $target = Join-Path $ProjectRoot $fileName
            if (Test-Path -LiteralPath $target -PathType Leaf) { Remove-Item -LiteralPath $target -Force }
            if ($backedFiles.Contains($fileName)) {
                Copy-Item -LiteralPath (Join-Path $backupRoot $fileName) -Destination $target -Force
            }
        }
        Write-UpdateLog 'Restauration terminée.'
        $oldLauncher = Join-Path $ProjectRoot 'START-STUDIO.bat'
        if (Test-Path -LiteralPath $oldLauncher -PathType Leaf) {
            Start-Process -FilePath $oldLauncher -WorkingDirectory $ProjectRoot
        }
    }
    catch {
        Write-UpdateLog "ERREUR RESTAURATION : $($_.Exception.Message)"
    }
    Write-Host "Échec de la mise à jour : $message" -ForegroundColor Red
    Write-Host "Journal : $LogPath"
    Start-Sleep -Seconds 8
    exit 1
}
finally {
    if ($stagingRoot -and (Test-Path -LiteralPath $stagingRoot)) {
        Remove-Item -LiteralPath $stagingRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}
