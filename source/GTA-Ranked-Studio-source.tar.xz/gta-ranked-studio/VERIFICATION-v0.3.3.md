# Vérification v0.3.3

## Correctif
Les captions mot à mot utilisent désormais un retour à la ligne explicite ASS pour éviter le débordement horizontal sur les vidéos verticales.

## Tests
- `tests/test_short_editor.py`
- `tests/test_transcribe.py`
- `tests/test_render_integration.py`

La validation finale du rendu doit être effectuée sur Windows avec FFmpeg et la build Whisper locale de l'utilisateur.


## Correctif de mise à jour v0.3.3.1
Lecture robuste du fichier VERSION.txt sous Windows PowerShell 5.1 et PowerShell 7. Le script n'attend plus une version source codée en dur.


## Correctif v0.3.3.2
Le parseur de VERSION.txt accepte désormais les numéros de version à trois ou quatre composants.
