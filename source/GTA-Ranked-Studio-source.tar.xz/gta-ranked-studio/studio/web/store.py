"""Accès SQLite pour l'interface web et les traitements locaux."""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


JOB_COLUMNS = {
    "status", "progress", "message", "source_path", "source_url", "streamer",
    "note", "duration", "output_path", "thumbnail_path", "error", "validated_at",
    "source_hash", "source_title", "metadata_json",
}


class Store:
    def __init__(self, database_path: Path) -> None:
        self.database_path = Path(database_path)
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self.initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.database_path, timeout=30)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA journal_mode = WAL")
        return connection

    def initialize(self) -> None:
        with self._connect() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS jobs (
                    id TEXT PRIMARY KEY,
                    kind TEXT NOT NULL DEFAULT 'short',
                    status TEXT NOT NULL,
                    progress INTEGER NOT NULL DEFAULT 0,
                    message TEXT NOT NULL DEFAULT '',
                    source_kind TEXT NOT NULL,
                    source_path TEXT,
                    source_url TEXT,
                    source_hash TEXT,
                    source_title TEXT,
                    streamer TEXT NOT NULL DEFAULT '',
                    note TEXT NOT NULL DEFAULT '',
                    duration REAL,
                    output_path TEXT,
                    thumbnail_path TEXT,
                    metadata_json TEXT NOT NULL DEFAULT '{}',
                    error TEXT,
                    rights_confirmed INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    validated_at TEXT
                );

                CREATE TABLE IF NOT EXISTS clips (
                    id TEXT PRIMARY KEY,
                    job_id TEXT NOT NULL UNIQUE,
                    source_hash TEXT,
                    source_path TEXT,
                    source_url TEXT,
                    source_title TEXT,
                    streamer TEXT NOT NULL DEFAULT '',
                    date_key TEXT NOT NULL,
                    duration REAL,
                    output_path TEXT,
                    thumbnail_path TEXT,
                    status TEXT NOT NULL DEFAULT 'ready',
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(job_id) REFERENCES jobs(id)
                );

                CREATE INDEX IF NOT EXISTS idx_jobs_created_at ON jobs(created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status);
                CREATE INDEX IF NOT EXISTS idx_clips_date ON clips(date_key);
                CREATE UNIQUE INDEX IF NOT EXISTS idx_jobs_source_hash ON jobs(source_hash) WHERE source_hash IS NOT NULL;
                CREATE UNIQUE INDEX IF NOT EXISTS idx_clips_source_hash ON clips(source_hash) WHERE source_hash IS NOT NULL;
                """
            )

    @staticmethod
    def now() -> str:
        return datetime.now(timezone.utc).isoformat(timespec="seconds")

    def create_job(self, job: dict[str, Any]) -> None:
        now = self.now()
        payload = {
            "id": job["id"],
            "kind": job.get("kind", "short"),
            "status": job.get("status", "queued"),
            "progress": int(job.get("progress", 0)),
            "message": job.get("message", "En attente"),
            "source_kind": job["source_kind"],
            "source_path": job.get("source_path"),
            "source_url": job.get("source_url"),
            "source_hash": job.get("source_hash"),
            "source_title": job.get("source_title"),
            "streamer": job.get("streamer", ""),
            "note": job.get("note", ""),
            "metadata_json": json.dumps(job.get("metadata", {}), ensure_ascii=False),
            "rights_confirmed": int(bool(job.get("rights_confirmed"))),
            "created_at": now,
            "updated_at": now,
        }
        columns = ", ".join(payload.keys())
        placeholders = ", ".join("?" for _ in payload)
        with self._connect() as connection:
            connection.execute(
                f"INSERT INTO jobs ({columns}) VALUES ({placeholders})",
                tuple(payload.values()),
            )

    def update_job(self, job_id: str, **fields: Any) -> None:
        unknown = set(fields) - JOB_COLUMNS
        if unknown:
            raise ValueError("Champs de job inconnus : " + ", ".join(sorted(unknown)))
        if not fields:
            return
        values = dict(fields)
        if "metadata_json" in values and not isinstance(values["metadata_json"], str):
            values["metadata_json"] = json.dumps(values["metadata_json"], ensure_ascii=False)
        values["updated_at"] = self.now()
        assignments = ", ".join(f"{column} = ?" for column in values)
        with self._connect() as connection:
            connection.execute(
                f"UPDATE jobs SET {assignments} WHERE id = ?",
                (*values.values(), job_id),
            )

    def get_job(self, job_id: str) -> dict[str, Any] | None:
        with self._connect() as connection:
            row = connection.execute("SELECT * FROM jobs WHERE id = ?", (job_id,)).fetchone()
        return self._job_dict(row) if row else None

    def list_jobs(self, limit: int = 50) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT * FROM jobs ORDER BY created_at DESC LIMIT ?", (limit,)
            ).fetchall()
        return [self._job_dict(row) for row in rows]

    def get_dashboard(self) -> dict[str, Any]:
        with self._connect() as connection:
            counts = connection.execute(
                """SELECT
                    COUNT(*) AS total,
                    SUM(CASE WHEN status IN ('queued', 'running') THEN 1 ELSE 0 END) AS processing,
                    SUM(CASE WHEN status = 'ready' THEN 1 ELSE 0 END) AS review,
                    SUM(CASE WHEN status = 'validated' THEN 1 ELSE 0 END) AS validated
                   FROM jobs"""
            ).fetchone()
            clips = connection.execute("SELECT COUNT(*) AS total FROM clips").fetchone()
        return {
            "total_jobs": int(counts["total"] or 0),
            "processing": int(counts["processing"] or 0),
            "to_review": int(counts["review"] or 0),
            "validated": int(counts["validated"] or 0),
            "clip_bank": int(clips["total"] or 0),
            "recent_jobs": self.list_jobs(8),
        }

    def find_duplicate_hash(self, source_hash: str) -> dict[str, Any] | None:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT * FROM jobs WHERE source_hash = ? LIMIT 1", (source_hash,)
            ).fetchone()
        return self._job_dict(row) if row else None

    def validate_job_and_add_to_clip_bank(self, job_id: str) -> dict[str, Any] | None:
        """Valide un rendu et l'ajoute au clip bank dans une transaction SQLite.

        Seuls les clips explicitement validés par l'utilisateur entrent dans la
        bibliothèque qui alimentera les Best Of. Un double clic ne crée pas de
        doublon et un crash ne peut pas séparer la validation de l'insertion.
        """
        now = self.now()
        with self._connect() as connection:
            row = connection.execute("SELECT * FROM jobs WHERE id = ?", (job_id,)).fetchone()
            if row is None or row["status"] != "ready":
                return None

            connection.execute(
                """UPDATE jobs
                   SET status = 'validated', message = 'Short validé', validated_at = ?, updated_at = ?
                   WHERE id = ? AND status = 'ready'""",
                (now, now, job_id),
            )
            validated_row = connection.execute("SELECT * FROM jobs WHERE id = ?", (job_id,)).fetchone()
            if validated_row is None:
                return None
            job = self._job_dict(validated_row)
            created_at = str(job.get("created_at") or now)
            date_key = created_at[:10]
            connection.execute(
                """INSERT OR IGNORE INTO clips (
                    id, job_id, source_hash, source_path, source_url, source_title,
                    streamer, date_key, duration, output_path, thumbnail_path, status, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'validated', ?)""",
                (
                    job["id"], job["id"], job.get("source_hash"), job.get("source_path"),
                    job.get("source_url"), job.get("source_title"), job.get("streamer", ""),
                    date_key, job.get("duration"), job.get("output_path"),
                    job.get("thumbnail_path"), created_at,
                ),
            )
        return job

    def list_clips(self, limit: int = 100) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT * FROM clips ORDER BY created_at DESC LIMIT ?", (limit,)
            ).fetchall()
        return [dict(row) for row in rows]

    @staticmethod
    def _job_dict(row: sqlite3.Row) -> dict[str, Any]:
        result = dict(row)
        try:
            result["metadata"] = json.loads(result.pop("metadata_json") or "{}")
        except json.JSONDecodeError:
            result["metadata"] = {}
        result["rights_confirmed"] = bool(result.get("rights_confirmed"))
        return result

    def recover_interrupted_jobs(self) -> None:
        """Replace les jobs interrompus dans la file après un arrêt du serveur."""
        with self._connect() as connection:
            connection.execute(
                "UPDATE jobs SET status='queued', progress=0, message='Reprise après redémarrage', updated_at=? WHERE status='running'",
                (self.now(),),
            )
