const state = { page: 'dashboard', file: null, toastTimer: null, modelPoll: null, updatePoll: null };
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

function toast(message, error = false) {
  const node = $('#toast');
  node.textContent = message;
  node.style.borderColor = error ? '#824747' : '#536044';
  node.classList.add('show');
  clearTimeout(state.toastTimer);
  state.toastTimer = setTimeout(() => node.classList.remove('show'), 5200);
}

function setPage(name) {
  state.page = name;
  $$('.page').forEach(page => page.classList.toggle('active', page.id === `page-${name}`));
  $$('.nav-item').forEach(item => item.classList.toggle('active', item.dataset.page === name));
  const labels = { dashboard: 'Vue d\'ensemble', shorts: 'Créer un Short', library: 'Clip library', bestof: 'Daily Best Of', settings: 'Paramètres' };
  $('#page-title').textContent = labels[name] || 'GTA Ranked Studio';
  if (name === 'shorts') loadJobs();
  if (name === 'library') loadLibrary();
  if (name === 'settings') { loadModels(); loadUpdates(); }
}

function escapeHtml(value = '') {
  return String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
}

function statusLabel(status) {
  return ({ queued: 'EN ATTENTE', running: 'EN COURS', ready: 'À VALIDER', validated: 'VALIDÉ', rejected: 'REJETÉ', error: 'ERREUR' })[status] || String(status || '').toUpperCase();
}

function outputUrlFromPath(filePath) {
  if (!filePath) return '';
  const parts = String(filePath).split(/[\\/]/).slice(-4);
  return `/outputs/${parts.map(encodeURIComponent).join('/')}`;
}

function jobCard(job) {
  const outputUrl = outputUrlFromPath(job.output_path);
  const thumbUrl = outputUrlFromPath(job.thumbnail_path);
  const metadata = job.metadata || {};
  const title = metadata.title || job.source_title || job.streamer || (job.source_kind === 'url' ? job.source_url : 'Clip importé') || 'Clip';
  let actions = '';
  if (job.status === 'ready') {
    actions = `<div class="job-actions"><a class="mini-button" href="${outputUrl}" target="_blank" rel="noopener">Prévisualiser ↗</a><a class="mini-button" href="${outputUrl}" download>Télécharger ↓</a><button class="mini-button" data-action="metadata" data-id="${job.id}">Métadonnées</button><button class="mini-button good" data-action="validate" data-id="${job.id}">Valider ✓</button><button class="mini-button" data-action="reject" data-id="${job.id}">Rejeter</button></div>`;
  } else if (job.status === 'validated') {
    actions = `<div class="job-actions"><a class="mini-button" href="${outputUrl}" target="_blank" rel="noopener">Ouvrir le Short ↗</a><span class="status-pill validated">✓ Validé</span><button class="mini-button" data-action="reprocess" data-id="${job.id}">Recréer ce Short</button></div>`;
  } else if (job.status === 'error') {
    actions = `<div class="job-actions"><button class="mini-button" data-action="details" data-id="${job.id}">Voir l'erreur</button><button class="mini-button" data-action="reprocess" data-id="${job.id}">Réessayer dans un nouveau job</button></div>`;
  } else if (job.status === 'rejected') {
    actions = `<div class="job-actions"><button class="mini-button" data-action="reprocess" data-id="${job.id}">Recréer ce Short</button></div>`;
  }
  const progress = Math.max(0, Math.min(100, Number(job.progress || 0)));
  const meta = [job.streamer, job.duration ? `${Number(job.duration).toFixed(1)} s` : '', new Date(job.created_at).toLocaleString('fr-FR')].filter(Boolean).join(' · ');
  const subtitleState = metadata.transcription_status === 'completed'
    ? 'Sous-titres mot à mot (DTW)'
    : metadata.transcription_status === 'completed_segment_fallback'
      ? 'Sous-titres par segment (DTW indisponible)'
      : metadata.transcription_message || '';
  return `<article class="job-card">
    ${thumbUrl ? `<img class="job-thumb" src="${thumbUrl}" alt="Miniature du Short">` : `<div class="job-thumb job-thumb-placeholder">▶</div>`}
    <div class="job-main"><strong title="${escapeHtml(title)}">${escapeHtml(title)}</strong><div class="job-meta">${escapeHtml(meta || job.source_kind.toUpperCase())}</div><div class="job-message">${escapeHtml(job.message || '')}${subtitleState ? ` · ${escapeHtml(subtitleState)}` : ''}${job.error ? ` · ${escapeHtml(job.error.slice(0, 200))}` : ''}</div>${['queued','running'].includes(job.status) ? `<div class="job-progress"><span style="width:${progress}%"></span></div>` : ''}${actions}</div>
    <div class="job-side"><span class="status-pill ${escapeHtml(job.status)}">${statusLabel(job.status)}</span></div>
  </article>`;
}

async function api(path, options = {}) {
  const response = await fetch(path, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.detail || data.message || `Erreur HTTP ${response.status}`);
  return data;
}

async function loadDashboard() {
  try {
    const data = await api('/api/dashboard');
    $('#stat-total').textContent = data.total_jobs;
    $('#stat-processing').textContent = data.processing;
    $('#stat-review').textContent = data.to_review;
    $('#stat-validated').textContent = data.validated;
    $('#nav-review-count').textContent = data.to_review;
    $('#recent-jobs').innerHTML = data.recent_jobs.length ? data.recent_jobs.map(jobCard).join('') : '<div class="empty-state">Aucun clip pour le moment. Ajoute ton premier fichier pour commencer.</div>';
  } catch (error) { toast(error.message, true); }
}

async function loadJobs() {
  try {
    const jobs = await api('/api/jobs?limit=100');
    $('#all-jobs').innerHTML = jobs.length ? jobs.map(jobCard).join('') : '<div class="empty-state">Tes clips apparaîtront ici après leur import.</div>';
    $('#nav-review-count').textContent = jobs.filter(job => job.status === 'ready').length;
  } catch (error) { toast(error.message, true); }
}

async function loadLibrary() {
  try {
    const clips = await api('/api/clips?limit=100');
    $('#clip-library').innerHTML = clips.length ? clips.map(clip => jobCard({
      id: clip.job_id, status: clip.status, progress: 100, source_kind: clip.source_url ? 'url' : 'upload',
      source_title: clip.source_title || 'Clip', streamer: clip.streamer, duration: clip.duration,
      output_path: clip.output_path, thumbnail_path: clip.thumbnail_path, message: 'Enregistré dans le clip bank', created_at: clip.created_at,
    })).join('') : '<div class="empty-state">Aucun clip enregistré.</div>';
  } catch (error) { toast(error.message, true); }
}

async function loadHealth() {
  try {
    const data = await api('/api/health');
    $('#gpu-name').textContent = data.gpu;
    $('#settings-gpu').textContent = data.gpu;
    const checks = [
      ['Serveur local', true, '127.0.0.1'],
      ['FFmpeg / FFprobe', data.ffmpeg && data.ffprobe, data.ffmpeg && data.ffprobe ? 'Détectés' : 'À vérifier'],
      ['Encodage AMD AMF', data.amf, data.amf ? 'H.264 matériel détecté' : 'Fallback CPU disponible'],
      ['Whisper CLI', data.whisper_cli, data.whisper_cli ? 'Installé' : 'À installer'],
      ['Modèle Whisper', data.whisper_model, data.whisper_model ? 'Installé' : 'À télécharger'],
    ];
    $('#system-checks').innerHTML = checks.map(([name, ok, detail]) => `<div class="system-check"><span class="check-dot ${ok ? '' : 'off'}"></span><span>${escapeHtml(name)}</span><span style="margin-left:auto;color:#79818a;font:9px var(--mono)">${escapeHtml(detail)}</span></div>`).join('');
  } catch (error) {
    $('#system-checks').innerHTML = '<div class="system-check"><span class="check-dot off"></span><span>Serveur local indisponible</span></div>';
  }
}

async function loadModels(forceRefresh = false) {
  try {
    const data = await api(`/api/models/status${forceRefresh ? '?refresh=true' : ''}`);
    const diagnostic = data.whisper_diagnostic || {};
    const engineLine = $('#whisper-engine-status');
    const engineDetails = $('#whisper-engine-details');
    if (diagnostic.available) {
      const backend = diagnostic.vulkan_detected ? 'Vulkan détecté' : (diagnostic.device_listing_supported ? 'Aucun périphérique Vulkan listé' : 'Backend GPU non vérifiable avec cette build');
      engineLine.textContent = `Moteur opérationnel · ${backend}`;
      engineDetails.textContent = `${diagnostic.path || ''} · ${diagnostic.dtw_supported ? 'timestamps mot à mot DTW disponibles' : 'DTW indisponible, fallback par segment'}`;
    } else {
      engineLine.textContent = 'Moteur absent ou non exécutable';
      engineDetails.textContent = diagnostic.message || 'Installe whisper.cpp puis actualise le diagnostic.';
    }

    const whisperLine = $('#whisper-model-status');
    if (data.status === 'downloading') {
      whisperLine.textContent = data.message || 'Téléchargement en cours...';
      $('#download-whisper-model').disabled = true;
      $('#download-whisper-model').textContent = 'Téléchargement...';
      $('#cancel-whisper-download').classList.remove('hidden');
      $('#whisper-progress-wrap').classList.remove('hidden');
      $('#whisper-progress-bar').style.width = `${data.progress || 0}%`;
      $('#whisper-progress-label').textContent = `${data.progress || 0} %`;
      state.modelPoll = setTimeout(loadModels, 1500);
    } else if (data.valid) {
      whisperLine.textContent = `Modèle valide · ${(data.size_bytes / (1024 ** 3)).toFixed(2)} Go · ${diagnostic.available ? 'prêt à transcrire' : 'en attente du moteur'}`;
      $('#download-whisper-model').disabled = true;
      $('#download-whisper-model').textContent = 'Modèle installé';
      $('#cancel-whisper-download').classList.add('hidden');
      $('#whisper-progress-wrap').classList.add('hidden');
    } else {
      whisperLine.textContent = data.status === 'invalid' ? 'Fichier existant invalide ou incomplet. Télécharge-le à nouveau.' : 'Modèle non installé.';
      $('#download-whisper-model').disabled = !diagnostic.available;
      $('#download-whisper-model').textContent = diagnostic.available ? 'Télécharger le modèle (~1,6 Go)' : 'Installer le moteur d’abord';
      $('#cancel-whisper-download').classList.add('hidden');
      $('#whisper-progress-wrap').classList.add('hidden');
    }
    const ollamaLine = $('#ollama-model-status');
    if (!data.ollama_running) ollamaLine.textContent = 'Ollama non détecté ou arrêté. Installe-le puis démarre-le pour activer la génération IA.';
    else if (!data.ollama_model_installed) ollamaLine.textContent = `Ollama fonctionne, mais le modèle ${data.ollama_model} n'est pas installé.`;
    else ollamaLine.textContent = `Opérationnel · ${data.ollama_model} disponible localement.`;
  } catch (error) {
    $('#whisper-model-status').textContent = error.message;
  }
}

async function loadUpdates() {
  const status = $('#update-check-status');
  const version = $('#update-current-version');
  const installButton = $('#install-update');
  installButton.classList.add('hidden');
  version.textContent = 'Vérification...';
  status.textContent = 'Contact de GitHub pour rechercher la dernière version stable...';
  try {
    const data = await api('/api/updates/check');
    version.textContent = `v${data.current_version}`;
    if (data.update_available) {
      status.textContent = `Une nouvelle version est disponible : v${data.latest_version} (actuellement v${data.current_version}).`;
      const notes = $('#update-release-notes');
      notes.textContent = data.release_notes || 'Aucune note de version fournie.';
      notes.classList.remove('hidden');
      installButton.textContent = `Installer la v${data.latest_version}`;
      installButton.classList.remove('hidden');
      installButton.disabled = false;
    } else {
      status.textContent = `Tu utilises la dernière version stable (${data.current_version}).`;
      $('#update-release-notes').classList.add('hidden');
    }
  } catch (error) {
    version.textContent = 'Connexion indisponible';
    status.textContent = error.message.includes('404')
      ? 'Aucune version publiée pour le moment. La première publication sera bientôt disponible.'
      : `Impossible de vérifier les mises à jour : ${error.message}`;
  }
}

async function installUpdate() {
  const button = $('#install-update');
  button.disabled = true;
  button.textContent = 'Préparation...';
  try {
    const result = await api('/api/updates/install', { method: 'POST' });
    toast(result.message || 'La mise à jour va démarrer.');
    $('#update-check-status').textContent = 'Téléchargement et vérification du paquet. GTA Ranked Studio va se fermer puis redémarrer automatiquement.';
    clearInterval(state.updatePoll);
    state.updatePoll = setInterval(async () => {
      try {
        const progress = await api('/api/updates/status');
        $('#update-check-status').textContent = progress.message || 'Mise à jour en cours...';
        if (progress.status === 'error') {
          clearInterval(state.updatePoll);
          button.disabled = false;
          button.textContent = 'Réessayer';
          toast(progress.message, true);
        } else if (progress.status === 'restarting') {
          clearInterval(state.updatePoll);
        }
      } catch {
        // Le serveur est en cours de fermeture avant son redémarrage.
        clearInterval(state.updatePoll);
      }
    }, 1500);
  } catch (error) {
    toast(error.message, true);
    button.disabled = false;
    button.textContent = 'Réessayer';
  }
}

function showSourceTab(kind) {
  $$('.source-tab').forEach(tab => tab.classList.toggle('active', tab.dataset.sourceTab === kind));
  $('#upload-form').classList.toggle('hidden', kind !== 'file');
  $('#url-form').classList.toggle('hidden', kind !== 'url');
}

async function submitForm(form, endpoint) {
  const button = $('button[type="submit"]', form);
  const oldText = button.innerHTML;
  button.disabled = true;
  button.textContent = 'Traitement de la demande...';
  try {
    const payload = new FormData(form);
    $$('[data-option-checkbox]', form).forEach(input => payload.set(input.name, input.checked ? 'true' : 'false'));
    const response = await fetch(endpoint, { method: 'POST', body: payload });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.detail || `Erreur HTTP ${response.status}`);
    toast(data.message || 'Clip ajouté à la file de traitement.');
    form.reset();
    state.file = null;
    const selected = $('#selected-file');
    if (selected) selected.textContent = '';
    await loadJobs();
    await loadDashboard();
  } catch (error) {
    toast(error.message, true);
  } finally {
    button.disabled = false;
    button.innerHTML = oldText;
  }
}

async function handleJobAction(button) {
  const id = button.dataset.id;
  const action = button.dataset.action;
  if (action === 'details') {
    const job = await api(`/api/jobs/${id}`);
    toast(job.error || 'Aucune information complémentaire.', true);
    return;
  }
  if (action === 'metadata') {
    const job = await api(`/api/jobs/${id}`);
    const metadata = job.metadata || {};
    const text = [metadata.title || 'Titre non généré', '', metadata.description || 'Description non générée'].join('\n');
    try { await navigator.clipboard.writeText(text); toast('Titre et description copiés dans le presse-papiers.'); }
    catch { toast(text); }
    return;
  }
  const endpoint = action === 'reprocess'
    ? `/api/jobs/${id}/reprocess`
    : `/api/jobs/${id}/${action}`;
  try {
    const result = await api(endpoint, { method: 'POST' });
    toast(action === 'reprocess' ? (result.message || 'Nouveau traitement lancé.') : (action === 'validate' ? 'Short validé.' : 'Short rejeté.'));
    await Promise.all([loadJobs(), loadDashboard(), state.page === 'library' ? loadLibrary() : Promise.resolve()]);
  } catch (error) { toast(error.message, true); }
}

function setFile(file) {
  if (!file) return;
  state.file = file;
  const input = $('#clip-file');
  const dataTransfer = new DataTransfer();
  dataTransfer.items.add(file);
  input.files = dataTransfer.files;
  $('#selected-file').textContent = `${file.name} · ${(file.size / 1024 / 1024).toFixed(1)} MB`;
}

async function startWhisperDownload() {
  try {
    await api('/api/models/whisper/download', { method: 'POST' });
    toast('Téléchargement du modèle Whisper lancé. Il fait environ 1,62 Go.');
    loadModels();
  } catch (error) { toast(error.message, true); }
}

async function cancelWhisperDownload() {
  try {
    await api('/api/models/whisper/cancel', { method: 'POST' });
    toast('Annulation du téléchargement demandée.');
    loadModels();
  } catch (error) { toast(error.message, true); }
}

function updateRangeOutput(input) {
  const output = input.parentElement.querySelector('output');
  if (output) output.textContent = `${input.value} %`;
}

function setupEvents() {
  $$('.nav-item').forEach(item => item.addEventListener('click', () => setPage(item.dataset.page)));
  $$('[data-go]').forEach(item => item.addEventListener('click', () => setPage(item.dataset.go)));
  $$('.source-tab').forEach(tab => tab.addEventListener('click', () => showSourceTab(tab.dataset.sourceTab)));
  $('#browse-file').addEventListener('click', () => $('#clip-file').click());
  $('#dropzone').addEventListener('click', event => { if (event.target.id !== 'browse-file') $('#clip-file').click(); });
  $('#clip-file').addEventListener('change', event => setFile(event.target.files[0]));
  const dropzone = $('#dropzone');
  ['dragenter','dragover'].forEach(name => dropzone.addEventListener(name, event => { event.preventDefault(); dropzone.classList.add('dragover'); }));
  ['dragleave','drop'].forEach(name => dropzone.addEventListener(name, event => { event.preventDefault(); dropzone.classList.remove('dragover'); }));
  dropzone.addEventListener('drop', event => setFile(event.dataTransfer.files[0]));
  $('#upload-form').addEventListener('submit', event => { event.preventDefault(); if (!$('#clip-file').files[0]) { toast('Sélectionne d’abord un fichier vidéo.', true); return; } submitForm(event.currentTarget, '/api/shorts/upload'); });
  $('#url-form').addEventListener('submit', event => { event.preventDefault(); submitForm(event.currentTarget, '/api/shorts/url'); });
  $('#refresh-jobs').addEventListener('click', () => loadJobs());
  $('#refresh-models').addEventListener('click', () => loadModels(true));
  $('#refresh-models-secondary').addEventListener('click', () => loadModels(true));
  $('#check-updates').addEventListener('click', loadUpdates);
  $('#install-update').addEventListener('click', installUpdate);
  $('#download-whisper-model').addEventListener('click', startWhisperDownload);
  $('#cancel-whisper-download').addEventListener('click', cancelWhisperDownload);
  $$('[data-crop-slider], [data-zoom-slider]').forEach(input => {
    updateRangeOutput(input);
    input.addEventListener('input', () => updateRangeOutput(input));
  });
  document.addEventListener('click', event => { const button = event.target.closest('[data-action]'); if (button) handleJobAction(button); });
}

setupEvents();
loadDashboard();
loadHealth();
setInterval(() => {
  loadDashboard();
  if (state.page === 'shorts') loadJobs();
  if (state.page === 'settings') loadModels();
}, 5000);
