﻿"""Génération de sous-titres ASS et d'overlays éditoriaux pour les Shorts."""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from PIL import Image, ImageDraw, ImageFont


@dataclass(frozen=True)
class WordTiming:
    start: float
    end: float
    text: str


def parse_srt(path: Path) -> list[WordTiming]:
    """Lit un SRT Whisper et récupère ses segments horodatés."""
    if not path.is_file():
        return []
    content = path.read_text(encoding="utf-8-sig", errors="replace")
    blocks = re.split(r"\r?\n\s*\r?\n", content.strip())
    result: list[WordTiming] = []
    time_pattern = re.compile(
        r"(?P<start>\d{2}:\d{2}:\d{2}[,.]\d{3})\s+-->\s+(?P<end>\d{2}:\d{2}:\d{2}[,.]\d{3})"
    )
    for block in blocks:
        lines = [line.strip() for line in block.splitlines() if line.strip()]
        match = next((time_pattern.search(line) for line in lines if time_pattern.search(line)), None)
        if not match:
            continue
        text_index = next((i for i, line in enumerate(lines) if time_pattern.search(line)), -1)
        text = " ".join(lines[text_index + 1:]).strip()
        text = re.sub(r"<[^>]+>", "", text)
        if not text:
            continue
        start = _srt_time(match.group("start"))
        end = _srt_time(match.group("end"))
        if end > start:
            result.append(WordTiming(start=start, end=end, text=text))
    return result


def _srt_time(value: str) -> float:
    hours, minutes, seconds = value.replace(",", ".").split(":")
    return int(hours) * 3600 + int(minutes) * 60 + float(seconds)


def _ass_time(seconds: float) -> str:
    total_cs = max(0, round(float(seconds) * 100))
    hours, remainder = divmod(total_cs, 360000)
    minutes, remainder = divmod(remainder, 6000)
    whole_seconds, centiseconds = divmod(remainder, 100)
    return f"{hours}:{minutes:02d}:{whole_seconds:02d}.{centiseconds:02d}"


def _clean_ass_text(value: str) -> str:
    cleaned = str(value or "").replace("\r", " ").replace("\n", " ")
    cleaned = cleaned.replace("\\", "／").replace("{", "｛").replace("}", "｝")
    return re.sub(r"\s+", " ", cleaned).strip()


def _wrap_words(value: str, max_words: int = 5) -> str:
    words = _clean_ass_text(value).split()
    if len(words) <= max_words:
        return " ".join(words)
    midpoint = min(max_words, (len(words) + 1) // 2)
    return " ".join(words[:midpoint]) + r"\N" + " ".join(words[midpoint:])


def _merge_punctuation(words: Iterable[WordTiming]) -> list[WordTiming]:
    output: list[WordTiming] = []
    punctuation = re.compile(r"^[,.;:!?)]")
    for word in words:
        text = _clean_ass_text(word.text)
        if not text:
            continue
        if output and (punctuation.match(text) or text.startswith("'")):
            previous = output[-1]
            output[-1] = WordTiming(previous.start, max(previous.end, word.end), previous.text + text)
        else:
            output.append(WordTiming(word.start, max(word.end, word.start + 0.04), text))
    return output


def _caption_events(words: list[WordTiming], width: int, height: int) -> list[str]:
    events: list[str] = []
    words = _merge_punctuation(words)

    # SRT fallback returns one timing per sentence/segment rather than per word.
    # Split those phrases into approximate word timings so captions stay readable
    # and the active-word treatment does not highlight an entire sentence.
    expanded: list[WordTiming] = []
    for item in words:
        parts = item.text.split()
        if len(parts) <= 1:
            expanded.append(item)
            continue
        weights = [max(1, len(part.strip(".,!?;:"))) for part in parts]
        total_weight = sum(weights)
        duration = max(0.04, item.end - item.start)
        cursor = item.start
        for part_index, (part, weight) in enumerate(zip(parts, weights)):
            next_cursor = (
                item.end if part_index == len(parts) - 1
                else cursor + duration * weight / total_weight
            )
            expanded.append(WordTiming(cursor, max(cursor + 0.04, next_cursor), part))
            cursor = next_cursor
    words = expanded

    groups: list[list[WordTiming]] = []
    current: list[WordTiming] = []
    for word in words:
        pause = word.start - current[-1].end if current else 0.0
        if current and (len(current) >= 4 or pause > 0.55):
            groups.append(current)
            current = []
        current.append(word)
    if current:
        groups.append(current)

    y = int(height * 0.79)
    x = width // 2
    for group in groups:
        for index, active in enumerate(group):
            next_word = group[index + 1] if index + 1 < len(group) else None
            end = next_word.start if next_word and next_word.start > active.start else active.end
            end = max(active.start + 0.06, min(end, active.end + 0.8 if next_word is None else end))
            caption_lines: list[list[str]] = [[]]
            line_length = 0
            max_line_chars = 16
            for word_index, word in enumerate(group):
                text = _clean_ass_text(word.text).upper()
                highlighted = (
                    r"{\c&H0000C8F5&}" + text + r"{\c&H00FFFFFF&}"
                    if word_index == index else text
                )
                plain_length = len(text)
                required = plain_length + (1 if caption_lines[-1] else 0)
                if caption_lines[-1] and line_length + required > max_line_chars:
                    caption_lines.append([])
                    line_length = 0
                caption_lines[-1].append(highlighted)
                line_length += plain_length + (1 if len(caption_lines[-1]) > 1 else 0)
            line = r"\N".join(" ".join(parts) for parts in caption_lines)
            start_stamp = _ass_time(active.start)
            end_stamp = _ass_time(end)
            events.append(
                f"Dialogue: 0,{start_stamp},{end_stamp},Caption,,0,0,0,,{{\\an2\\pos({x},{y})}}{line}"
            )
    return events


def create_ass_file(
    output_path: Path,
    *,
    words: list[WordTiming] | None = None,
    hook_text: str = "",
    context_text: str = "",
    handle: str = "@GTARankedStudio",
    badge_text: str = "GTA VI",
    width: int = 1080,
    height: int = 1920,
    font_name: str = "Arial",
    captions_enabled: bool = True,
    brand_enabled: bool = True,
) -> Path:
    """Crée une piste ASS avec hook, contexte, branding et captions mot à mot."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    font = _clean_ass_text(font_name) or "Arial"
    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {width}
PlayResY: {height}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding
Style: Caption,{font},66,&H00FFFFFF,&H0000C8F5,&H00101010,&H80000000,-1,0,0,0,100,100,0,0,1,5,2,2,70,70,300,1
Style: Hook,{font},78,&H0000C8F5,&H00FFFFFF,&H00101010,&H90000000,-1,0,0,0,100,100,1,0,1,5,2,8,75,75,340,1
Style: Context,{font},34,&H00FFFFFF,&H00FFFFFF,&H00101010,&H90000000,-1,0,0,0,100,100,0,0,1,3,1,8,80,80,490,1
Style: Brand,{font},27,&H00FFFFFF,&H00FFFFFF,&H00101010,&H80000000,-1,0,0,0,100,100,0,0,1,3,1,7,55,55,90,1
Style: Handle,{font},25,&H00FFFFFF,&H00FFFFFF,&H00101010,&H80000000,-1,0,0,0,100,100,0,0,1,3,1,9,55,55,90,1

[Events]
Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text
"""
    events: list[str] = []
    if brand_enabled:
        events.append(
            f"Dialogue: 3,0:00:00.00,9:59:59.99,Brand,,0,0,0,,{{\\an7\\pos(65,90)}}{_clean_ass_text(badge_text)}"
        )
        events.append(
            f"Dialogue: 3,0:00:00.00,9:59:59.99,Handle,,0,0,0,,{{\\an9\\pos({width - 65},90)}}{_clean_ass_text(handle)}"
        )
    clean_hook = _clean_ass_text(hook_text)
    if clean_hook:
        events.append(
            f"Dialogue: 2,0:00:00.00,0:00:02.60,Hook,,0,0,0,,{{\\an8\\pos({width // 2},{int(height * 0.20)})}}{_wrap_words(clean_hook, 5)}"
        )
    clean_context = _clean_ass_text(context_text)
    if clean_context:
        events.append(
            f"Dialogue: 2,0:00:00.35,0:00:03.50,Context,,0,0,0,,{{\\an8\\pos({width // 2},{int(height * 0.29)})}}{_wrap_words(clean_context, 7)}"
        )
    if captions_enabled and words:
        events.extend(_caption_events(words, width, height))

    output_path.write_text(header + "\n".join(events) + "\n", encoding="utf-8-sig")
    return output_path


def apply_thumbnail_overlay(
    image_path: Path,
    text: str,
    *,
    font_path: Path | None = None,
    max_words: int = 4,
) -> Path:
    """Ajoute un titre court, très lisible, à la miniature verticale."""
    if not image_path.is_file():
        raise FileNotFoundError(f"Miniature introuvable : {image_path}")
    words = _clean_ass_text(text).split()[:max_words]
    label = " ".join(words).upper() or "GTA VI MOMENT"
    with Image.open(image_path) as source:
        image = source.convert("RGB")
    draw = ImageDraw.Draw(image, "RGBA")
    width, height = image.size

    candidates: list[Path] = []
    if font_path:
        candidates.append(Path(font_path))
    candidates.extend([
        Path("C:/Windows/Fonts/arialbd.ttf"),
        Path("C:/Windows/Fonts/impact.ttf"),
        Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
    ])
    font = None
    font_size = max(24, int(width * 0.078))
    for candidate in candidates:
        if candidate.is_file():
            try:
                font = ImageFont.truetype(str(candidate), font_size)
                break
            except OSError:
                continue
    if font is None:
        try:
            font = ImageFont.truetype("arialbd.ttf", font_size)
        except OSError:
            font = ImageFont.load_default()

    # Deux lignes maximum pour rester lisible sur l'aperçu Shorts.
    tokens = label.split()
    lines: list[str] = []
    current = ""
    max_line_width = width * 0.86
    for token in tokens:
        candidate_line = f"{current} {token}".strip()
        if current and draw.textbbox((0, 0), candidate_line, font=font, stroke_width=2)[2] > max_line_width:
            lines.append(current)
            current = token
        else:
            current = candidate_line
    if current:
        lines.append(current)
    if len(lines) > 2:
        lines = [" ".join(lines[:-1]), lines[-1]]

    spacing = max(4, int(font_size * 0.10))
    boxes = [draw.textbbox((0, 0), line, font=font, stroke_width=3) for line in lines]
    text_width = max((box[2] - box[0] for box in boxes), default=0)
    text_height = sum(box[3] - box[1] for box in boxes) + spacing * (len(lines) - 1)
    padding_x = int(width * 0.055)
    padding_y = int(height * 0.018)
    box_width = min(width - int(width * 0.06), text_width + 2 * padding_x)
    box_height = text_height + 2 * padding_y
    left = (width - box_width) // 2
    top = int(height * 0.66)
    top = min(max(int(height * 0.45), top), height - box_height - int(height * 0.08))
    draw.rounded_rectangle(
        (left, top, left + box_width, top + box_height),
        radius=max(8, int(width * 0.018)),
        fill=(8, 9, 11, 205),
        outline=(245, 196, 0, 220),
        width=max(2, int(width * 0.003)),
    )
    y = top + padding_y
    for index, line in enumerate(lines):
        box = draw.textbbox((0, 0), line, font=font, stroke_width=3)
        line_width = box[2] - box[0]
        line_height = box[3] - box[1]
        x = (width - line_width) // 2 - box[0]
        draw.text(
            (x, y - box[1]), line, font=font, fill=(255, 255, 255, 255),
            stroke_width=max(2, int(width * 0.004)), stroke_fill=(0, 0, 0, 255),
        )
        y += line_height + spacing

    image.save(image_path, format="JPEG", quality=92, optimize=True)
    return image_path


def select_excerpt_range(
    duration: float,
    peak_timestamp: float,
    words: list[WordTiming] | None = None,
    *,
    threshold_seconds: float = 45.0,
    lead_seconds: float = 1.5,
    tail_seconds: float = 2.0,
    minimum_seconds: float = 15.0,
    maximum_seconds: float = 45.0,
) -> tuple[float, float]:
    """Sélectionne un passage resserré autour du pic, si la source est longue.

    Les mots transcrits servent à repérer une fin de phrase ou une pause après
    le pic. Sans transcription, une fenêtre de secours centrée sur le pic est
    choisie. Les clips courts sont conservés intégralement.
    """
    duration = max(0.0, float(duration))
    if duration <= 0:
        return 0.0, 0.0
    if duration <= threshold_seconds:
        return 0.0, duration

    peak = max(0.0, min(float(peak_timestamp), duration))
    start = max(0.0, peak - max(0.0, lead_seconds))
    end_after_payoff: float | None = None
    ordered = sorted(words or [], key=lambda item: (item.start, item.end))
    punctuation = re.compile(r"[.!?][\"')\]]*$")
    after_peak = [item for item in ordered if item.end >= peak]
    if after_peak:
        for item in after_peak:
            clean = _clean_ass_text(item.text)
            next_item = next((candidate for candidate in ordered if candidate.start >= item.end and candidate is not item), None)
            pause_after = (next_item.start - item.end) if next_item else 0.0
            if punctuation.search(clean) or pause_after >= 0.75:
                end_after_payoff = item.end
                break
        if end_after_payoff is None:
            nearby = [item for item in after_peak if item.start <= peak + 10.0]
            if nearby:
                end_after_payoff = nearby[-1].end

    if end_after_payoff is None:
        end_after_payoff = peak + 12.0
    end = min(duration, max(peak + 2.0, end_after_payoff + max(0.0, tail_seconds)))

    # Garantit assez de contexte pour que le moment reste compréhensible.
    if end - start < minimum_seconds:
        desired_start = max(0.0, peak - max(1.5, minimum_seconds * 0.565))
        start = min(start, desired_start)
        end = min(duration, max(end, start + minimum_seconds))
        if end - start < minimum_seconds:
            start = max(0.0, end - minimum_seconds)

    if end - start > maximum_seconds:
        start = max(0.0, min(start, peak - min(12.0, maximum_seconds * 0.35)))
        end = min(duration, start + maximum_seconds)
        if end - start > maximum_seconds:
            start = end - maximum_seconds

    start = max(0.0, min(start, duration))
    end = max(start, min(end, duration))
    return round(start, 3), round(end, 3)


def rebase_word_timings(words: list[WordTiming], trim_start: float, trim_end: float) -> list[WordTiming]:
    """Garde les mots dans la coupe et ramène leurs horodatages à zéro."""
    result: list[WordTiming] = []
    for word in words:
        if word.end <= trim_start or word.start >= trim_end:
            continue
        start = round(max(0.0, word.start - trim_start), 3)
        end = round(max(start + 0.04, min(trim_end, word.end) - trim_start), 3)
        result.append(WordTiming(start, end, word.text))
    return result


def _format_srt_time(seconds: float) -> str:
    milliseconds = max(0, round(float(seconds) * 1000))
    hours, remainder = divmod(milliseconds, 3_600_000)
    minutes, remainder = divmod(remainder, 60_000)
    whole_seconds, milliseconds = divmod(remainder, 1000)
    return f"{hours:02d}:{minutes:02d}:{whole_seconds:02d},{milliseconds:03d}"


def write_srt_file(output_path: Path, words: list[WordTiming]) -> Path:
    """Écrit un SRT en conservant les timestamps mot à mot."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    blocks = []
    for index, word in enumerate(words, start=1):
        start = max(0.0, word.start)
        end = max(start + 0.04, word.end)
        blocks.append(
            f"{index}\n{_format_srt_time(start)} --> {_format_srt_time(end)}\n{_clean_ass_text(word.text)}"
        )
    output_path.write_text("\n\n".join(blocks) + ("\n" if blocks else ""), encoding="utf-8")
    return output_path
