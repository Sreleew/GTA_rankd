"""Intégration locale de whisper.cpp avec timestamps de tokens DTW."""

from __future__ import annotations

import array
import json
import logging
import math
import re
import shutil
import subprocess
import sys
import wave
from pathlib import Path
from typing import Any

from studio.web.short_editor import WordTiming, parse_srt

logger = logging.getLogger(__name__)


class TranscriptionError(RuntimeError):
    """Erreur de transcription exploitable par le moteur de rendu."""


def _resolve_binary(value: str | Path) -> Path | None:
    candidate = Path(value).expanduser()
    if candidate.is_file():
        return candidate.resolve()
    discovered = shutil.which(str(value))
    return Path(discovered).resolve() if discovered else None


def _binary_invocation(binary: Path) -> list[str]:
    """Construit la commande multiplateforme pour un exécutable ou un script Python.

    whisper-cli.exe reste lancé directement. Les scripts Python utilisés par les tests
    (et les éventuels wrappers locaux) sont lancés via l'interpréteur courant :
    Windows ne sait pas exécuter un script portant seulement un shebang Unix.
    """
    if binary.suffix.lower() == ".py":
        return [sys.executable, str(binary)]
    return [str(binary)]



def inspect_whisper_cli(binary_value: str | Path, *, timeout: int = 12) -> dict[str, Any]:
    """Vérifie le binaire et les options réellement exposées par cette build."""
    binary = _resolve_binary(binary_value)
    if binary is None:
        return {
            "available": False, "path": str(binary_value), "version": None,
            "dtw_supported": False, "device_listing_supported": False,
            "devices": [], "vulkan_detected": False,
            "message": "whisper-cli.exe introuvable dans tools/whisper.cpp.",
        }
    command = _binary_invocation(binary)
    try:
        result = subprocess.run(
            [*command, "--help"], cwd=str(binary.parent), capture_output=True,
            text=True, encoding="utf-8", errors="replace", timeout=timeout, check=False,
        )
    except subprocess.TimeoutExpired:
        return {
            "available": False, "path": str(binary), "version": None,
            "dtw_supported": False, "device_listing_supported": False,
            "devices": [], "vulkan_detected": False,
            "message": "whisper-cli ne répond pas à --help dans le délai imparti.",
        }
    except OSError as exc:
        return {
            "available": False, "path": str(binary), "version": None,
            "dtw_supported": False, "device_listing_supported": False,
            "devices": [], "vulkan_detected": False,
            "message": f"Impossible de lancer whisper-cli : {exc}",
        }

    help_text = (result.stdout or "") + "\n" + (result.stderr or "")
    if result.returncode not in (0, 1) or not help_text.strip():
        detail = help_text.strip()[-500:] or f"Code de sortie {result.returncode}"
        return {
            "available": False, "path": str(binary), "version": None,
            "dtw_supported": False, "device_listing_supported": False,
            "devices": [], "vulkan_detected": False,
            "message": f"Le binaire est présent mais son démarrage a échoué : {detail}",
        }

    dtw_supported = "-dtw" in help_text and "-ojf" in help_text
    device_listing_supported = "--list-devices" in help_text
    devices: list[str] = []
    if device_listing_supported:
        try:
            device_result = subprocess.run(
                [*command, "--list-devices"], cwd=str(binary.parent), capture_output=True,
                text=True, encoding="utf-8", errors="replace", timeout=timeout, check=False,
            )
            device_text = (device_result.stdout or "") + "\n" + (device_result.stderr or "")
            devices = [line.strip() for line in device_text.splitlines() if line.strip()]
        except (OSError, subprocess.TimeoutExpired):
            devices = []
    vulkan_detected = any("vulkan" in line.lower() for line in devices)
    version_match = re.search(r"(?:whisper\.cpp|whisper)\s+v?([0-9]+\.[0-9]+(?:\.[0-9]+)?)", help_text, re.IGNORECASE)
    version = version_match.group(1) if version_match else None
    return {
        "available": True, "path": str(binary), "version": version,
        "dtw_supported": dtw_supported,
        "device_listing_supported": device_listing_supported,
        "devices": devices[:12], "vulkan_detected": vulkan_detected,
        "message": "Moteur Whisper exécutable." + (
            " DTW disponible." if dtw_supported else " DTW absent, les captions resteront par segment."
        ),
    }

def _parse_whisper_timestamp(value: Any) -> float | None:
    if not isinstance(value, str):
        return None
    match = re.fullmatch(r"(\d+):(\d{2}):(\d{2})[.,](\d{1,3})", value.strip())
    if not match:
        return None
    hours, minutes, seconds, milliseconds = match.groups()
    return int(hours) * 3600 + int(minutes) * 60 + int(seconds) + int(milliseconds.ljust(3, "0")) / 1000


def parse_whisper_json_words(path: Path) -> list[WordTiming]:
    """Convertit le JSON complet whisper.cpp avec -dtw en vrais mots horodatés.

    whisper.cpp expose les timestamps DTW par token en unités de 10 ms.
    Les tokens sont regroupés en mots en respectant les espaces de début de token.
    """
    if not path.is_file():
        return []
    try:
        payload = json.loads(path.read_text(encoding="utf-8-sig", errors="replace"))
    except (OSError, json.JSONDecodeError):
        logger.warning("Le JSON complet Whisper est absent ou illisible : %s", path)
        return []

    segments = payload.get("transcription") if isinstance(payload, dict) else None
    if not isinstance(segments, list):
        return []

    result: list[WordTiming] = []
    special_pattern = re.compile(r"^(?:\[[A-Z0-9_:/ .-]+\]|<\|[^>]+\|>)$")

    for segment in segments:
        if not isinstance(segment, dict):
            continue
        tokens = segment.get("tokens")
        if not isinstance(tokens, list) or not tokens:
            continue

        segment_times = segment.get("timestamps") if isinstance(segment.get("timestamps"), dict) else {}
        segment_start = _parse_whisper_timestamp(segment_times.get("from")) or 0.0
        segment_end = _parse_whisper_timestamp(segment_times.get("to"))
        if segment_end is None:
            segment_end = segment_start + 1.0

        token_items: list[tuple[str, float]] = []
        for token in tokens:
            if not isinstance(token, dict):
                continue
            raw_text = str(token.get("text") or "")
            if not raw_text or special_pattern.fullmatch(raw_text.strip()):
                continue
            # DTW timestamps are stored in 10 ms units by whisper.cpp.
            raw_time = token.get("t_dtw")
            try:
                token_start = float(raw_time) / 100.0
            except (TypeError, ValueError):
                continue
            if not math.isfinite(token_start) or token_start < 0:
                continue
            token_items.append((raw_text, max(segment_start, token_start)))

        # Without DTW, recent whisper.cpp builds may leave t_dtw at zero for
        # every token. In that case the segment SRT is the honest fallback.
        if len(token_items) > 1:
            token_times = [item[1] for item in token_items]
            if max(token_times) - min(token_times) < 0.02:
                continue

        word_groups: list[tuple[str, float]] = []
        current_text = ""
        current_start: float | None = None
        for raw_text, token_start in token_items:
            text = raw_text
            starts_new_word = text[:1].isspace() or text.startswith(("Ġ", "▁"))
            if text.startswith(("Ġ", "▁")):
                text = text[1:]
            text = text.strip() if starts_new_word else text
            if not text:
                continue
            if starts_new_word and current_text.strip():
                word_groups.append((current_text.strip(), current_start if current_start is not None else segment_start))
                current_text = text
                current_start = token_start
            elif not current_text:
                current_text = text
                current_start = token_start
            else:
                current_text += text

        if current_text.strip():
            word_groups.append((current_text.strip(), current_start if current_start is not None else segment_start))

        for index, (text, start) in enumerate(word_groups):
            next_start = word_groups[index + 1][1] if index + 1 < len(word_groups) else segment_end
            end = min(segment_end, max(start + 0.06, next_start))
            if end <= start:
                end = start + 0.12
            result.append(WordTiming(round(start, 3), round(end, 3), text))

    result.sort(key=lambda item: (item.start, item.end))
    # Remove overlaps introduced by adjacent Whisper segments.
    normalized: list[WordTiming] = []
    for index, word in enumerate(result):
        end = word.end
        if index + 1 < len(result) and result[index + 1].start > word.start:
            end = min(end, result[index + 1].start)
        normalized.append(WordTiming(word.start, max(word.start + 0.04, end), word.text))
    return normalized


def extract_audio_wav(
    input_path: Path,
    wav_path: Path,
    *,
    ffmpeg: str = "ffmpeg",
    timeout: int = 180,
) -> Path:
    ffmpeg_bin = _resolve_binary(ffmpeg) or (Path(shutil.which(ffmpeg)) if shutil.which(ffmpeg) else None)
    if ffmpeg_bin is None:
        raise TranscriptionError("FFmpeg est introuvable pour extraire l'audio.")
    wav_path.parent.mkdir(parents=True, exist_ok=True)
    command = [
        str(ffmpeg_bin), "-hide_banner", "-loglevel", "error", "-y", "-i", str(input_path.resolve()),
        "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", str(wav_path.resolve()),
    ]
    result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout, check=False)
    if result.returncode != 0 or not wav_path.is_file() or wav_path.stat().st_size <= 44:
        detail = (result.stderr or "Aucune piste audio exploitable.").strip()
        raise TranscriptionError(detail[-1500:])
    return wav_path


def transcribe_with_whisper_cpp(
    audio_path: Path,
    *,
    whisper_cli: str | Path,
    model_path: Path,
    output_dir: Path,
    language: str = "en",
    threads: int = 0,
    vad_model_path: Path | None = None,
    timeout: int = 1800,
    dtw_model_preset: str = "large.v3.turbo",
) -> dict[str, Any]:
    binary = _resolve_binary(whisper_cli)
    if binary is None:
        return {"status": "unavailable", "reason": "whisper-cli.exe introuvable", "words": [], "text": ""}
    if not model_path.is_file():
        return {
            "status": "model_missing",
            "reason": f"Modèle Whisper absent : {model_path}",
            "words": [],
            "text": "",
        }

    output_dir.mkdir(parents=True, exist_ok=True)
    output_base = output_dir / "transcript"
    srt_path = output_base.with_suffix(".srt")
    json_path = output_base.with_suffix(".json")

    # Détecte le support DTW du binaire au lieu de supposer qu'il est présent.
    # Le préfixe fonctionne aussi sous Windows pour les wrappers de test .py.
    binary_command = _binary_invocation(binary)
    supports_dtw = False
    try:
        help_result = subprocess.run(
            [*binary_command, "--help"], cwd=str(binary.parent), capture_output=True,
            text=True, encoding="utf-8", errors="replace", timeout=20, check=False,
        )
        help_text = (help_result.stdout or "") + "\n" + (help_result.stderr or "")
        supports_dtw = "-dtw" in help_text and "-ojf" in help_text
    except (OSError, subprocess.TimeoutExpired):
        logger.info("Impossible de lire l'aide Whisper, utilisation du mode SRT standard.")

    command = [
        *binary_command, "-m", str(model_path.resolve()), "-f", str(audio_path.resolve()),
        "-l", language or "en", "-osrt", "-of", str(output_base), "-np",
    ]
    if supports_dtw:
        command.extend(["-dtw", dtw_model_preset, "-ojf"])
    if threads > 0:
        command.extend(["-t", str(threads)])
    if vad_model_path and vad_model_path.is_file():
        command.extend(["--vad", "-vm", str(vad_model_path.resolve())])

    try:
        result = subprocess.run(
            command, cwd=str(binary.parent), capture_output=True, text=True,
            encoding="utf-8", errors="replace", timeout=timeout, check=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise TranscriptionError(f"Whisper a dépassé le délai de {timeout} secondes.") from exc
    except OSError as exc:
        raise TranscriptionError(f"Impossible de lancer whisper.cpp : {exc}") from exc
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "Erreur whisper.cpp inconnue").strip()
        raise TranscriptionError(detail[-2500:])

    words = parse_whisper_json_words(json_path) if supports_dtw else []
    timestamp_mode = "word_dtw" if words else "segment_srt"
    if not words:
        words = parse_srt(srt_path)
    transcript_text = " ".join(word.text for word in words).strip()
    if not words:
        return {
            "status": "no_speech", "reason": "Aucune parole détectée.", "words": [], "text": "",
            "srt_path": str(srt_path) if srt_path.exists() else None,
            "timestamp_mode": timestamp_mode,
        }
    status = "completed" if timestamp_mode == "word_dtw" else "completed_segment_fallback"
    reason = (
        "Transcription locale terminée avec timestamps DTW par token regroupés en mots."
        if timestamp_mode == "word_dtw"
        else "Transcription locale terminée. Ce binaire ne fournit pas de timestamps DTW exploitables : captions par segment."
    )
    return {
        "status": status,
        "reason": reason,
        "words": words,
        "text": transcript_text,
        "srt_path": str(srt_path) if srt_path.exists() else None,
        "json_path": str(json_path) if json_path.exists() else None,
        "timestamp_mode": timestamp_mode,
    }


def detect_audio_peak_timestamp(wav_path: Path, window_seconds: float = 0.35) -> float:
    """Repère la fenêtre audio la plus énergique dans un WAV mono 16 kHz."""
    if not wav_path.is_file():
        return 0.0
    try:
        with wave.open(str(wav_path), "rb") as audio:
            sample_rate = audio.getframerate()
            frames = audio.readframes(audio.getnframes())
            channels = audio.getnchannels()
            sample_width = audio.getsampwidth()
        if sample_width != 2 or sample_rate <= 0:
            return 0.0
        samples = array.array("h")
        samples.frombytes(frames)
        if channels > 1:
            samples = array.array("h", samples[::channels])
        window_size = max(1, int(sample_rate * window_seconds))
        best_rms = -1.0
        best_center = 0.0
        for start in range(0, len(samples), window_size // 2 or 1):
            chunk = samples[start:start + window_size]
            if len(chunk) < max(1, window_size // 3):
                continue
            square_sum = sum(int(value) * int(value) for value in chunk)
            rms = math.sqrt(square_sum / len(chunk))
            if rms > best_rms:
                best_rms = rms
                best_center = (start + len(chunk) / 2) / sample_rate
        return max(0.0, best_center)
    except (OSError, wave.Error, ValueError):
        logger.exception("Impossible d'analyser le niveau audio pour détecter le pic.")
        return 0.0
