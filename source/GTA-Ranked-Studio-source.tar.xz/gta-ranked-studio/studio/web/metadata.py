"""Génération de métadonnées via Ollama local, avec fallback déterministe."""

from __future__ import annotations

import json
import logging
import re
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


def _limit_words(value: str, maximum: int) -> str:
    words = str(value or "").split()
    return " ".join(words[:maximum]).strip()


def _fallback_metadata(
    *, streamer: str, note: str, source_url: str, transcript: str, custom_hook: str, custom_context: str
) -> dict[str, Any]:
    safe_streamer = streamer.strip() or "GTA VI creator"
    note_text = note.strip()
    context = _limit_words(custom_context or note_text, 10)
    hook = _limit_words(custom_hook or "WAIT FOR IT...", 8)
    if note_text and not custom_hook:
        hook = _limit_words(note_text, 8)
    title = f"GTA VI: {safe_streamer}'s moment" if streamer.strip() else "GTA VI: One unexpected moment"
    title = title[:60]
    description_lines = [
        "A GTA VI moment worth watching.",
        "Watch until the end.",
    ]
    credit_source = source_url.strip() or "Local source"
    description_lines.extend(["", f"Clip: {safe_streamer} ({credit_source})", "", "#GTA6 #GTAVI #Gaming"])
    return {
        "hook_text": hook,
        "context_card": context,
        "title": title,
        "title_variants": {
            "youtube_shorts": title,
            "tiktok": title,
            "instagram": title,
        },
        "description": "\n".join(description_lines),
        "hashtags": ["#GTA6", "#GTAVI", "#Gaming"],
        "thumbnail_text": "GTA VI MOMENT",
        "transcript_excerpt": transcript[:1200],
        "generator": "local_fallback",
    }


def generate_short_metadata(
    *,
    streamer: str = "",
    note: str = "",
    source_url: str = "",
    source_title: str = "",
    transcript: str = "",
    custom_hook: str = "",
    custom_context: str = "",
    ollama_base_url: str = "http://127.0.0.1:11434",
    ollama_model: str = "qwen2.5:7b-instruct",
    prompt_path: Path | None = None,
    timeout: int = 120,
    retries: int = 2,
) -> dict[str, Any]:
    fallback = _fallback_metadata(
        streamer=streamer or source_title, note=note, source_url=source_url,
        transcript=transcript, custom_hook=custom_hook, custom_context=custom_context,
    )
    if not transcript.strip() and not note.strip() and not custom_hook.strip() and not custom_context.strip():
        return fallback
    prompt_rules = "You are an English-language GTA VI short-form video editor. Never invent facts, names, events, locations, mechanics or reactions. Use only the transcript and the metadata below. Return valid JSON only. hook_text must be at most 8 words; context_card at most 10 words; title at most 60 characters; thumbnail_text at most 4 words; hashtags at most 3. description must contain 2 short lines, then a credit line."
    if prompt_path and prompt_path.is_file():
        prompt_rules += "\n\n" + prompt_path.read_text(encoding="utf-8", errors="replace")
    payload = {
        "streamer": streamer,
        "source_title": source_title,
        "note": note,
        "source_url": source_url,
        "transcript": transcript[:6000],
        "required_json": {
            "hook_text": "string",
            "context_card": "string",
            "title": "string",
            "title_variants": {"youtube_shorts": "string", "tiktok": "string", "instagram": "string"},
            "description": "string",
            "hashtags": ["string"],
            "thumbnail_text": "string",
        },
    }
    request_body = json.dumps({
        "model": ollama_model,
        "system": prompt_rules,
        "prompt": json.dumps(payload, ensure_ascii=False),
        "stream": False,
        "format": "json",
        "options": {"temperature": 0.4},
    }).encode("utf-8")
    request = urllib.request.Request(
        ollama_base_url.rstrip("/") + "/api/generate",
        data=request_body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    for attempt in range(max(1, retries + 1)):
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                outer = json.loads(response.read().decode("utf-8", errors="replace"))
            generated = outer.get("response", "")
            data = json.loads(generated) if isinstance(generated, str) else generated
            if not isinstance(data, dict):
                raise ValueError("Réponse Ollama non structurée.")
            title = str(data.get("title", fallback["title"]))[:60]
            # Les champs saisis par l'utilisateur sont prioritaires sur le LLM.
            hook = _limit_words(custom_hook or str(data.get("hook_text", fallback["hook_text"])), 8)
            context = _limit_words(custom_context or str(data.get("context_card", fallback["context_card"])), 10)
            variants = data.get("title_variants") if isinstance(data.get("title_variants"), dict) else {}
            hashtags = data.get("hashtags") if isinstance(data.get("hashtags"), list) else fallback["hashtags"]
            hashtags = [str(tag).strip() for tag in hashtags if str(tag).strip()][:3]
            description = str(data.get("description", fallback["description"])).strip()
            # Credit is always appended by the application, not left to the model.
            credit_line = f"Clip: {streamer or source_title or 'GTA VI creator'} ({source_url or 'Local source'})"
            description = "\n".join([line for line in description.splitlines() if not line.lower().startswith("clip:")]).strip()
            description = "\n".join([description, "", credit_line, "", " ".join(hashtags)]).strip()
            return {
                "hook_text": hook,
                "context_card": context,
                "title": title,
                "title_variants": {
                    "youtube_shorts": str(variants.get("youtube_shorts", title))[:60],
                    "tiktok": str(variants.get("tiktok", title))[:80],
                    "instagram": str(variants.get("instagram", title))[:80],
                },
                "description": description,
                "hashtags": hashtags,
                "thumbnail_text": _limit_words(str(data.get("thumbnail_text", fallback["thumbnail_text"])), 4),
                "transcript_excerpt": transcript[:1200],
                "generator": "ollama_local",
            }
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError, ValueError, KeyError) as exc:
            logger.info("Ollama indisponible ou réponse invalide (tentative %s) : %s", attempt + 1, exc)
    return fallback
