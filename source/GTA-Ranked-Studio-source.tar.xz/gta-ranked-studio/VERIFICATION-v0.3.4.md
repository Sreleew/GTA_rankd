# Vérification v0.3.4

## Mise à jour intégrée
- Vérification GitHub Releases via l'API publique.
- Comparaison numérique de version.
- Téléchargement HTTPS du ZIP et du fichier SHA256SUMS.txt.
- Vérification SHA-256 avant extraction.
- Vérification de l'intégrité ZIP et de la structure attendue.
- Application de la mise à jour par un script PowerShell externe dans `%LOCALAPPDATA%`.
- Sauvegarde/restauration des fichiers de code.
- Redémarrage de l'application après mise à jour.

## Données préservées
`config.yaml`, `.venv`, `data`, `inbox`, `out`, `logs`, `work`, `models`, `tools`, `assets` utilisateur et prompts actifs.

## À valider sur Windows
La fermeture de `pythonw.exe`, le remplacement des fichiers, le redémarrage et l'accès à une Release publique doivent être testés sur un poste Windows.
