# Vérifications v0.3.0

Vérifications réalisées dans l'environnement de construction :

- `python -m pytest -q` : 54 tests réussis, 1 test ignoré. Le test ignoré nécessite Windows PowerShell 5.1, absent de l'environnement Linux de construction.
- `python -m compileall -q studio tests` : réussi.
- `node --check studio/web/static/app.js` : réussi.
- Test d'intégration FFmpeg sur une vidéo synthétique 16:9 : sortie verticale contrôlée par FFprobe, piste audio présente et miniature générée.
- Test du cadrage plein écran, de la coupe, des captions ASS et du zoom progressif.
- Test du mix audio avec l'effet whoosh original optionnel.
- Tests de parsing des timestamps DTW whisper.cpp et du fallback SRT par segments.
- Test de l'API locale et du parcours import/rendu/validation.

Limites de vérification :

- L'installateur et l'assistant de mise à jour PowerShell 5.1 doivent encore être exécutés sur Windows.
- L'encodage AMF a été détecté par le diagnostic v0.2.6 sur le PC utilisateur, mais le rendu AMF n'a pas pu être exécuté dans l'environnement de construction Linux.
- Le rendu d'intégration a utilisé `libx264`.
- Le modèle Whisper et Ollama sont optionnels ; les tests utilisent des exécutables simulés pour vérifier DTW et le fallback, ils ne valident pas une transcription réelle avec la voix de l'utilisateur.
- Le scoring et l'assemblage Daily Best Of restent à développer.
