# Verifications v0.3.1

## Correctif

La v0.3.0 executait les faux executables Whisper des tests comme s'ils etaient des binaires natifs. Sous Windows, un script portant un shebang Unix sans extension executable provoquait `WinError 193`.

La v0.3.1 :
- utilise des fixtures de test nommees `*.py` ;
- lance ces wrappers avec `sys.executable` ;
- continue de lancer directement le vrai binaire natif `whisper-cli.exe` ;
- conserve les tests de detection DTW et de fallback SRT.

## Tests

Verification realisee apres extraction de l'archive :
- `python -m compileall -q studio tests` : OK ;
- `python -m pytest -q` : **55 passed, 1 skipped** ;
- `node --check studio/web/static/app.js` : OK ;
- `unzip -t gta-ranked-studio-v0.3.1.zip` : OK.

Le test ignore necessite Windows PowerShell 5.1, qui n'est pas disponible dans l'environnement de construction. L'installateur et l'assistant de mise a jour doivent encore etre executes sur Windows reel.

## Limites importantes

- L'archive ne contient pas le binaire natif `whisper-cli.exe`. Le diagnostic de l'utilisateur avait detecte Vulkan mais pas le binaire Whisper ni le modele. La transcription reelle reste indisponible tant que le moteur natif et le modele ne sont pas installes.
- Le modele `ggml-large-v3-turbo.bin` n'est pas inclus dans l'archive.
- Les tests DTW/fallback utilisent des wrappers de simulation et ne valident pas une transcription audio reelle.
- L'encodage AMD AMF doit etre valide sur le PC cible.
