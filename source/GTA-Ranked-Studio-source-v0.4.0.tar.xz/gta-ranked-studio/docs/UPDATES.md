# Mises à jour GTA Ranked Studio

## Côté utilisateur

Dans GTA Ranked Studio, ouvrir **Paramètres > Mises à jour**, cliquer sur **Rechercher une mise à jour**, puis sur **Télécharger et installer** si une version est proposée. L'application se ferme et se relance après installation.

La première installation d'une version qui contient le système d'update (v0.3.4) est une mise à jour de transition depuis v0.3.3.3 : l'ancien fichier `UPDATE-FROM-ARCHIVE.bat` reste nécessaire une seule dernière fois. Après cette transition, plus besoin d'extraire des ZIP manuellement.

## Côté publication

Le dépôt public `Sreleew/GTA_rankd` est la source des releases stables.

1. Synchroniser `VERSION.txt`, `pyproject.toml` et le fichier `NOTES-vX.Y.Z.txt`.
2. Commit/push les modifications sur `main`.
3. Soit pousser un tag `vX.Y.Z`, soit lancer le workflow manuel **Build and publish GTA Ranked Studio** depuis l'onglet Actions.
4. Pour le workflow manuel, saisir le même numéro que `VERSION.txt`.
5. Vérifier que la Release contient :
   - `GTA-Ranked-Studio-vX.Y.Z.zip`
   - `SHA256SUMS.txt`

Le paquet est généré par `installer/build_release_package.py`. Le script exclut les environnements virtuels, les vidéos, les rendus, les bases de données, les journaux et les modèles/outils locaux.

## Sécurité et intégrité

- Le client ne contacte que l'API GitHub de ce dépôt et des URL d'assets de Releases GitHub en HTTPS.
- Le client vérifie la somme SHA-256 avant installation.
- Le ZIP est testé avant extraction.
- L'installateur n'écrase pas `config.yaml` ni les données personnelles.
- Les dossiers `studio`, `installer` et `tests` sont sauvegardés sous `work/updates/rollback-*`.
- L'installation est restaurée si une erreur survient pendant le remplacement.
- La mise à jour est lancée hors du processus de l'application, puis l'application redémarre.

## Limites connues de v0.3.4

Le téléchargement, le hash et la structure du ZIP sont vérifiés. Le script d'installation PowerShell doit encore être validé sur Windows réel, car le pipeline de test exécuté dans un environnement non-Windows ne peut pas simuler le verrouillage de processus et le redémarrage Windows.


## v0.3.5 : Whisper DTW

Le diagnostic exige les options `-dtw`, `-ojf` et `-nfa`. Le traitement ajoute `-nfa` pour désactiver Flash Attention et laisser whisper.cpp calculer les timestamps DTW. La validation finale consiste à confirmer des valeurs `t_dtw` non négatives sur les tokens parlés.


## v0.3.6 : journalisation de l’updater

Le journal `last-update.log` est initialisé avant le lancement PowerShell et `powershell-output.log` capture sa sortie console. Si PowerShell échoue immédiatement, le serveur GTA Ranked Studio reste actif et l’erreur est affichée dans l’interface. L’installateur utilise des tableaux simples compatibles Windows PowerShell 5.1 et écrit sa progression dans le journal.


## v0.4.0 : Moments forts

La page Moments forts ajoute l'analyse locale de fichiers vidéo et de VOD/clips Twitch. Les VOD peuvent être limitées à une plage de 3 heures maximum. L'analyse combine énergie audio, densité de transcription Whisper et mots de réaction pour proposer jusqu'à huit passages de 35 secondes. Le candidat sélectionné est envoyé au pipeline Shorts existant via un découpage `source_range`.

La première version n'analyse pas encore l'image et ne prétend pas comprendre la scène du jeu. Les scores classent des signaux audio/texte et doivent être validés par l'utilisateur.
