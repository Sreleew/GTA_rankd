from __future__ import annotations

import array
import wave
from pathlib import Path

from studio.web.highlights import read_audio_energy, score_highlight_candidates, write_wav_chunk
from studio.web.short_editor import WordTiming
from studio.web.store import Store


def _write_test_wav(path: Path) -> None:
    rate = 16000
    with wave.open(str(path), "wb") as audio:
        audio.setnchannels(1)
        audio.setsampwidth(2)
        audio.setframerate(rate)
        for second in range(20):
            amplitude = 26000 if 8 <= second < 12 else 2500
            frames = array.array("h", [amplitude] * rate)
            audio.writeframes(frames.tobytes())


def test_read_audio_energy_detects_loud_windows(tmp_path: Path) -> None:
    audio_path = tmp_path / "energy.wav"
    _write_test_wav(audio_path)
    windows = read_audio_energy(audio_path, window_seconds=1)
    assert len(windows) == 20
    assert max(item["rms"] for item in windows[8:12]) > 5 * max(item["rms"] for item in windows[:8])


def test_score_candidates_returns_bounded_ranked_non_overlapping_results() -> None:
    audio = [
        {"start": float(second), "end": float(second + 2), "rms": 0.03 if 40 <= second < 48 else 0.005}
        for second in range(0, 120, 2)
    ]
    words = [
        WordTiming(40.0, 40.4, "BRO"),
        WordTiming(41.0, 41.4, "WHAT"),
        WordTiming(42.0, 42.6, "NO"),
        WordTiming(43.0, 43.5, "INSANE"),
    ]
    candidates = score_highlight_candidates(120, audio, words, candidate_seconds=30, max_candidates=5)
    assert candidates
    assert len(candidates) <= 5
    assert [item["rank"] for item in candidates] == list(range(1, len(candidates) + 1))
    assert all(0 <= item["start_time"] < item["end_time"] <= 120 for item in candidates)
    assert all(item["end_time"] - item["start_time"] <= 30 for item in candidates)
    assert any("Mots de réaction détectés" in item["reasons"] for item in candidates)
    assert [item["score"] for item in candidates] == sorted(
        (item["score"] for item in candidates), reverse=True
    )


def test_score_short_twitch_clip_returns_single_candidate() -> None:
    candidates = score_highlight_candidates(
        24,
        [{"start": 0, "end": 2, "rms": 0.02}, {"start": 2, "end": 4, "rms": 0.04}],
        [WordTiming(2, 3, "NO"), WordTiming(3, 4, "BRO")],
        candidate_seconds=35,
    )
    assert len(candidates) == 1
    assert candidates[0]["start_time"] == 0
    assert candidates[0]["end_time"] == 24


def test_highlight_scans_and_candidates_are_persisted(tmp_path: Path) -> None:
    store = Store(tmp_path / "clips.sqlite")
    store.create_highlight_scan({
        "id": "scan-123", "source_kind": "upload", "source_path": "local-vod.mp4",
        "rights_confirmed": True, "window_start": 10.0, "window_end": 80.0,
    })
    store.update_highlight_scan("scan-123", status="completed", progress=100, message="Analyse terminée")
    store.save_highlight_candidates("scan-123", [{
        "rank": 1, "start_time": 25.0, "end_time": 60.0,
        "media_start": 25.0, "media_end": 60.0, "score": 82.5,
        "audio_score": 0.9, "speech_score": 0.7, "reaction_score": 1.0,
        "reasons": ["Pic d'énergie audio", "Mots de réaction détectés"],
        "transcript": "BRO WHAT NO",
    }])
    scan = store.get_highlight_scan("scan-123")
    candidates = store.list_highlight_candidates("scan-123")
    assert scan and scan["status"] == "completed"
    assert scan["rights_confirmed"] is True
    assert len(candidates) == 1
    assert candidates[0]["score"] == 82.5
    assert candidates[0]["reasons"] == ["Pic d'énergie audio", "Mots de réaction détectés"]


def test_write_wav_chunk_sets_the_actual_frame_count(tmp_path: Path) -> None:
    source_path = tmp_path / "source.wav"
    _write_test_wav(source_path)
    with wave.open(str(source_path), "rb") as source:
        params = source.getparams()
        chunk_path = tmp_path / "chunk.wav"
        write_wav_chunk(source, chunk_path, start_frame=5 * params.framerate, frame_count=3 * params.framerate, params=params)
    with wave.open(str(chunk_path), "rb") as chunk:
        assert chunk.getnframes() == 3 * params.framerate
        assert chunk.getnframes() / chunk.getframerate() == 3


def test_silent_audio_does_not_create_random_highlight_candidates() -> None:
    windows = [{"start": float(index * 2), "end": float(index * 2 + 2), "rms": 0.0} for index in range(30)]
    assert score_highlight_candidates(60, windows, []) == []
