"""Local highlight scanning for long GTA VODs and Twitch clips."""
from __future__ import annotations

import array
import json
import logging
import math
import queue
import re
import shutil
import threading
import time
import uuid
import wave
from pathlib import Path
from statistics import median
from typing import Any

from studio.config import AppConfig
from studio.web.short_editor import WordTiming
from studio.web.short_renderer import MediaError, probe_media
from studio.web.store import Store
from studio.web.transcribe import TranscriptionError, extract_audio_wav, transcribe_with_whisper_cpp

logger = logging.getLogger(__name__)

MAX_SCAN_SECONDS = 3 * 60 * 60
TRANSCRIPTION_CHUNK_SECONDS = 5 * 60
CANDIDATE_SECONDS = 35.0
MAX_CANDIDATES = 8
REACTION_CUES = {
    "bro", "bruh", "no", "what", "wow", "whoa", "holy", "shit", "fuck", "damn",
    "crazy", "insane", "run", "dead", "killed", "kill", "shoot", "police", "help",
    "oh", "god", "wait", "yo", "nah", "clutch", "nice", "wtf", "omg", "sick",
    "actually", "seriously", "impossible", "screaming", "laughing",
}


def _format_section_time(seconds: float) -> str:
    milliseconds = max(0, round(float(seconds) * 1000))
    hours, remainder = divmod(milliseconds, 3_600_000)
    minutes, remainder = divmod(remainder, 60_000)
    whole_seconds, milliseconds = divmod(remainder, 1000)
    return f"{hours:02d}:{minutes:02d}:{whole_seconds:02d}.{milliseconds:03d}"


def _words_for_window(words: list[WordTiming], start: float, end: float) -> list[WordTiming]:
    return [word for word in words if word.end > start and word.start < end]


def read_audio_energy(wav_path: Path, *, window_seconds: float = 2.0) -> list[dict[str, float]]:
    """Read a mono 16 kHz PCM WAV incrementally and return RMS windows."""
    windows: list[dict[str, float]] = []
    with wave.open(str(wav_path), "rb") as audio:
        rate = audio.getframerate()
        channels = audio.getnchannels()
        width = audio.getsampwidth()
        if rate <= 0 or width != 2:
            raise MediaError("Le WAV d'analyse doit être en PCM 16 bits.")
        frames_per_window = max(1, int(rate * window_seconds))
        start_frame = 0
        while True:
            raw = audio.readframes(frames_per_window)
            if not raw:
                break
            samples = array.array("h")
            samples.frombytes(raw)
            if channels > 1:
                samples = array.array("h", samples[::channels])
            if not samples:
                break
            square_sum = sum(int(value) * int(value) for value in samples)
            rms = math.sqrt(square_sum / len(samples)) / 32768.0
            duration = len(samples) / rate
            windows.append({
                "start": start_frame / rate,
                "end": start_frame / rate + duration,
                "rms": float(rms),
            })
            start_frame += len(raw) // (width * channels)
    return windows


def score_highlight_candidates(
    duration: float,
    audio_windows: list[dict[str, float]],
    words: list[WordTiming],
    *,
    candidate_seconds: float = CANDIDATE_SECONDS,
    max_candidates: int = MAX_CANDIDATES,
) -> list[dict[str, Any]]:
    """Rank candidate excerpts using audio energy, speech density and reaction cues.

    This is deliberately a transparent first-pass heuristic. It does not claim
    to understand the visuals or guarantee that a segment is entertaining.
    """
    duration = max(0.0, float(duration))
    if duration <= 0:
        return []
    clip_length = min(float(candidate_seconds), duration)
    if duration <= clip_length + 0.01:
        starts = [0.0]
    else:
        hop = max(5.0, min(12.0, clip_length / 3.0))
        starts = []
        current = 0.0
        while current + clip_length <= duration + 0.01:
            starts.append(current)
            current += hop
        if not starts or starts[-1] < duration - clip_length:
            starts.append(max(0.0, duration - clip_length))

    rms_values = [item["rms"] for item in audio_windows if item.get("rms", 0) >= 0]
    if rms_values:
        sorted_rms = sorted(rms_values)
        p50 = sorted_rms[int((len(sorted_rms) - 1) * 0.50)]
        p90 = sorted_rms[int((len(sorted_rms) - 1) * 0.90)]
        p98 = sorted_rms[int((len(sorted_rms) - 1) * 0.98)]
    else:
        p50 = p90 = p98 = 0.0
    audio_span = max(0.0001, p98 - p50)

    ranked: list[dict[str, Any]] = []
    for start in starts:
        end = min(duration, start + clip_length)
        local_audio = [item["rms"] for item in audio_windows if item["end"] > start and item["start"] < end]
        local_audio.sort(reverse=True)
        top_count = max(1, min(5, len(local_audio)))
        peak_average = sum(local_audio[:top_count]) / top_count if local_audio else 0.0
        audio_score = max(0.0, min(1.0, (peak_average - p50) / audio_span))

        local_words = _words_for_window(words, start, end)
        speech_density = len(local_words) / max(1.0, end - start)
        speech_score = max(0.0, min(1.0, speech_density / 1.35))
        cue_count = 0
        for word in local_words:
            tokens = re.findall(r"[a-z']+", word.text.lower())
            cue_count += sum(1 for token in tokens if token in REACTION_CUES)
        reaction_score = max(0.0, min(1.0, cue_count / 3.0))

        # Weight the acoustic signal most heavily while rewarding conversational
        # activity and reaction language. The score is a ranking, not a verdict.
        score = 100.0 * (0.55 * audio_score + 0.25 * speech_score + 0.20 * reaction_score)
        reasons: list[str] = []
        if audio_score >= 0.55:
            reasons.append("Pic d'énergie audio")
        if speech_score >= 0.55:
            reasons.append("Dialogue soutenu")
        if reaction_score > 0:
            reasons.append("Mots de réaction détectés")
        if not reasons:
            reasons.append("Activité audio repérée")
        transcript = " ".join(word.text.strip() for word in local_words).strip()
        if score < 8.0:
            continue
        ranked.append({
            "start_time": round(start, 3),
            "end_time": round(end, 3),
            "score": round(score, 1),
            "audio_score": round(audio_score, 3),
            "speech_score": round(speech_score, 3),
            "reaction_score": round(reaction_score, 3),
            "reasons": reasons,
            "transcript": transcript[:700],
        })

    ranked.sort(key=lambda item: item["score"], reverse=True)
    selected: list[dict[str, Any]] = []
    min_separation = max(12.0, clip_length * 0.55)
    for candidate in ranked:
        center = (candidate["start_time"] + candidate["end_time"]) / 2
        if any(
            abs(center - ((chosen["start_time"] + chosen["end_time"]) / 2)) < min_separation
            for chosen in selected
        ):
            continue
        selected.append(candidate)
        if len(selected) >= max_candidates:
            break
    # Keep the score order so #1 is genuinely the strongest candidate.
    for index, candidate in enumerate(selected, start=1):
        candidate["rank"] = index
    return selected


def write_wav_chunk(
    source: wave.Wave_read,
    output_path: Path,
    *,
    start_frame: int,
    frame_count: int,
    params: Any,
) -> Path:
    """Write an exact WAV chunk with a correct frame count in its header."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    source.setpos(max(0, int(start_frame)))
    raw = source.readframes(max(0, int(frame_count)))
    actual_frames = len(raw) // max(1, params.sampwidth * params.nchannels)
    with wave.open(str(output_path), "wb") as chunk:
        chunk.setparams((params.nchannels, params.sampwidth, params.framerate, actual_frames, params.comptype, params.compname))
        chunk.writeframes(raw)
    return output_path


class HighlightScanner:
    """Background scanner for local VODs and Twitch VOD/clip URLs."""

    def __init__(self, config: AppConfig, store: Store) -> None:
        self.config = config
        self.store = store
        self._queue: queue.Queue[str] = queue.Queue()
        self._started = False
        self._lock = threading.Lock()

    def start(self) -> None:
        with self._lock:
            if self._started:
                return
            self._started = True
            self.store.recover_interrupted_highlight_scans()
            for scan in self.store.list_highlight_scans(100):
                if scan["status"] == "queued":
                    self._queue.put(scan["id"])
            threading.Thread(target=self._run, name="gta-highlight-scanner", daemon=True).start()

    def submit(self, scan_id: str) -> None:
        self.start()
        self._queue.put(scan_id)

    def _run(self) -> None:
        while True:
            scan_id = self._queue.get()
            try:
                self._process(scan_id)
            except Exception:
                logger.exception("Analyse des moments forts échouée pour %s", scan_id)
                self.store.update_highlight_scan(
                    scan_id, status="error", progress=0,
                    message="Échec de l'analyse", error="Erreur interne. Consulte le journal local.",
                )
            finally:
                self._queue.task_done()

    def _process(self, scan_id: str) -> None:
        scan = self.store.get_highlight_scan(scan_id)
        if not scan or scan["status"] not in {"queued", "running"}:
            return
        self.store.update_highlight_scan(
            scan_id, status="running", progress=3, message="Préparation de la source", error=None,
        )
        source_path = Path(scan["source_path"]) if scan.get("source_path") else None
        base_offset = 0.0
        source_duration_hint: float | None = None
        temp_dir: Path | None = None
        transcription_available = False
        try:
            if source_path is None and scan.get("source_url"):
                self.store.update_highlight_scan(scan_id, progress=8, message="Téléchargement de la source Twitch")
                source_path, info = self._download(scan_id, scan)
                base_offset = float(scan.get("window_start") or 0.0) if scan.get("window_end") is not None else 0.0
                try:
                    source_duration_hint = float(info.get("duration") or 0.0) or None
                except (TypeError, ValueError):
                    source_duration_hint = None
                self.store.update_highlight_scan(
                    scan_id,
                    source_path=str(source_path.resolve()),
                    source_title=str(info.get("title") or scan.get("source_title") or "Twitch source"),
                    streamer=str(info.get("uploader") or info.get("channel") or scan.get("streamer") or ""),
                )
                scan = self.store.get_highlight_scan(scan_id) or scan
                scan["source_path"] = str(source_path)
            if source_path is None or not source_path.is_file():
                raise MediaError("Fichier source introuvable.")

            media = probe_media(source_path, str(self.config.get("executables", "ffprobe", default="ffprobe")))
            source_duration = float(media["duration"])
            requested_start = float(scan.get("window_start") or 0.0)
            requested_end = scan.get("window_end")
            if requested_end is None:
                local_start = 0.0
                local_end = source_duration
                base_offset = 0.0
            elif scan.get("source_kind") == "url":
                # yt-dlp has already downloaded the requested VOD section.
                local_start = 0.0
                local_end = source_duration
            else:
                local_start = requested_start
                local_end = float(requested_end)
            analysis_duration = local_end - local_start
            if analysis_duration <= 0:
                raise MediaError("La plage de temps sélectionnée est invalide.")
            if analysis_duration > MAX_SCAN_SECONDS:
                raise MediaError("La première version limite une analyse à 3 heures. Sélectionne une plage plus courte.")
            if local_end > source_duration + 0.25:
                raise MediaError("La fin de la plage dépasse la durée de la vidéo.")

            self.store.update_highlight_scan(
                scan_id, source_duration=source_duration_hint or (source_duration + base_offset),
                progress=15, message=f"Analyse audio sur {analysis_duration / 60:.1f} minutes",
            )
            temp_dir = self.config.path_for("paths", "temp") / "highlights" / scan_id
            temp_dir.mkdir(parents=True, exist_ok=True)
            audio_path = temp_dir / "analysis-audio.wav"
            extract_audio_wav(
                source_path, audio_path,
                ffmpeg=str(self.config.get("executables", "ffmpeg", default="ffmpeg")),
                timeout=max(600, int(analysis_duration * 5)),
                start_seconds=local_start,
                duration_seconds=analysis_duration,
            )
            audio_windows = read_audio_energy(audio_path)
            self.store.update_highlight_scan(scan_id, progress=28, message="Analyse des niveaux audio terminée")

            words: list[WordTiming] = []
            model_path = self.config.path_for("transcription", "model_path")
            whisper_cli = self.config.path_for("executables", "whisper_cli")
            vad_raw = self.config.get("transcription", "vad_model_path", default="")
            vad_model = self.config.root / str(vad_raw) if vad_raw else None
            transcription_available = model_path.is_file() and whisper_cli.is_file()
            if transcription_available:
                with wave.open(str(audio_path), "rb") as audio:
                    params = audio.getparams()
                    total_frames = audio.getnframes()
                    chunk_frames = TRANSCRIPTION_CHUNK_SECONDS * params.framerate
                    chunk_count = max(1, math.ceil(total_frames / chunk_frames))
                    for index in range(chunk_count):
                        frame_start = min(total_frames, index * chunk_frames)
                        frame_count = min(chunk_frames, total_frames - frame_start)
                        if frame_count <= 0:
                            continue
                        chunk_path = temp_dir / f"audio-{index:04d}.wav"
                        write_wav_chunk(audio, chunk_path, start_frame=frame_start, frame_count=frame_count, params=params)
                        chunk_output = temp_dir / f"whisper-{index:04d}"
                        try:
                            result = transcribe_with_whisper_cpp(
                                chunk_path,
                                whisper_cli=whisper_cli,
                                model_path=model_path,
                                output_dir=chunk_output,
                                language=str(self.config.get("transcription", "language", default="en")),
                                threads=int(self.config.get("transcription", "threads", default=0)),
                                vad_model_path=vad_model,
                                timeout=1800,
                            )
                            offset = local_start + (index * TRANSCRIPTION_CHUNK_SECONDS)
                            words.extend(
                                WordTiming(word.start + offset, word.end + offset, word.text)
                                for word in result.get("words", [])
                            )
                        except TranscriptionError as exc:
                            logger.warning("Whisper chunk %s échoué pour le scan %s : %s", index, scan_id, exc)
                        finally:
                            chunk_path.unlink(missing_ok=True)
                        progress = 28 + int(48 * (index + 1) / chunk_count)
                        self.store.update_highlight_scan(
                            scan_id, progress=progress,
                            message=f"Transcription Whisper : segment {index + 1}/{chunk_count}",
                        )
            else:
                self.store.update_highlight_scan(
                    scan_id, progress=75,
                    message="Whisper absent : classement basé uniquement sur l'énergie audio",
                )

            candidates = score_highlight_candidates(analysis_duration, audio_windows, words)
            stored_candidates = []
            for candidate in candidates:
                media_start = local_start + candidate["start_time"]
                media_end = local_start + candidate["end_time"]
                stored_candidates.append({
                    **candidate,
                    "start_time": round(base_offset + media_start, 3),
                    "end_time": round(base_offset + media_end, 3),
                    "media_start": round(media_start, 3),
                    "media_end": round(media_end, 3),
                })
            self.store.save_highlight_candidates(scan_id, stored_candidates)
            audio_path.unlink(missing_ok=True)
            self.store.update_highlight_scan(
                scan_id, status="completed", progress=100,
                message=f"Analyse terminée : {len(stored_candidates)} passage(s) candidat(s)",
                metadata_json={
                    "analysis_duration": analysis_duration,
                    "base_offset": base_offset,
                    "transcription_available": transcription_available,
                    "transcription_used": bool(words),
                    "transcribed_words": len(words),
                    "scoring_method": "audio_energy + speech_density + reaction_cues",
                    "limitations": "Classement heuristique audio/texte. Pas encore d'analyse visuelle du gameplay.",
                },
            )
            if temp_dir is not None:
                shutil.rmtree(temp_dir, ignore_errors=True)
        except Exception as exc:
            logger.exception("Analyse du scan %s échouée", scan_id)
            if temp_dir is not None:
                shutil.rmtree(temp_dir, ignore_errors=True)
            self.store.update_highlight_scan(
                scan_id, status="error", progress=0, message="Échec de l'analyse", error=str(exc)[:2500],
            )

    def _download(self, scan_id: str, scan: dict[str, Any]) -> tuple[Path, dict[str, Any]]:
        try:
            from yt_dlp import YoutubeDL
        except ImportError as exc:
            raise MediaError("yt-dlp n'est pas installé. Répare les dépendances depuis l'installation.") from exc
        download_dir = self.config.path_for("paths", "temp") / "downloads"
        download_dir.mkdir(parents=True, exist_ok=True)
        last_progress_update = {"at": 0.0, "percent": -1}

        def progress_hook(data: dict[str, Any]) -> None:
            if data.get("status") != "downloading":
                return
            total = data.get("total_bytes") or data.get("total_bytes_estimate")
            downloaded = data.get("downloaded_bytes") or 0
            fragment_index = data.get("fragment_index")
            fragment_count = data.get("fragment_count")
            if total:
                percent = int(max(0, min(100, downloaded * 100 / total)))
            elif fragment_index is not None and fragment_count:
                percent = int(max(0, min(100, int(fragment_index) * 100 / int(fragment_count))) )
            else:
                percent = -1
            now = time.monotonic()
            if percent >= 0 and (percent >= last_progress_update["percent"] + 2 or now - last_progress_update["at"] >= 5):
                last_progress_update.update(at=now, percent=percent)
                self.store.update_highlight_scan(
                    scan_id, progress=8 + int(percent * 0.10),
                    message=f"Téléchargement Twitch : {percent}%",
                )

        options: dict[str, Any] = {
            "outtmpl": str(download_dir / f"highlight-{scan_id}.%(ext)s"),
            "format": "bv*+ba/best",
            "merge_output_format": "mp4",
            "noplaylist": True,
            "quiet": True,
            "no_warnings": True,
            "restrictfilenames": True,
            "concurrent_fragment_downloads": 4,
            "retries": 5,
            "fragment_retries": 5,
            "progress_hooks": [progress_hook],
        }
        start = scan.get("window_start")
        end = scan.get("window_end")
        try:
            # Fetch metadata first so a multi-hour VOD is never downloaded in
            # full by accident when the user has not selected a time window.
            with YoutubeDL({**options, "skip_download": True}) as probe_downloader:
                info = probe_downloader.extract_info(str(scan["source_url"]), download=False)
            source_duration = float(info.get("duration") or 0.0)
            if start is None and end is None and source_duration > MAX_SCAN_SECONDS:
                raise MediaError(
                    f"Cette VOD dure {source_duration / 3600:.1f} h. Pour éviter un téléchargement massif, "
                    "renseigne un début et une fin (plage maximale : 3 h)."
                )
            if start is not None and end is not None:
                if source_duration and float(end) > source_duration:
                    raise MediaError("La fin de la plage dépasse la durée de la VOD Twitch.")
                options["download_sections"] = [f"*{_format_section_time(float(start))}-{_format_section_time(float(end))}"]
                options["force_keyframes_at_cuts"] = True
            with YoutubeDL(options) as downloader:
                info = downloader.extract_info(str(scan["source_url"]), download=True)
                downloaded = Path(downloader.prepare_filename(info))
            if not downloaded.is_file():
                candidates = sorted(
                    download_dir.glob(f"highlight-{scan_id}.*"),
                    key=lambda path: path.stat().st_mtime,
                    reverse=True,
                )
                downloaded = next(
                    (path for path in candidates if path.is_file() and path.suffix.lower() in {".mp4", ".mkv", ".webm", ".mov"}),
                    downloaded,
                )
            if not downloaded.is_file():
                raise MediaError("yt-dlp a terminé sans produire de fichier vidéo exploitable.")
            return downloaded, info
        except Exception as exc:
            raise MediaError(f"Téléchargement Twitch impossible : {exc}") from exc
