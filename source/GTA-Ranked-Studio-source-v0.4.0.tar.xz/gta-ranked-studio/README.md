# GTA Ranked Studio

Application locale Windows pour transformer des clips et des VOD GTA en Shorts verticaux.

Version actuelle : **0.4.0**.

## Fonctionnalités

- Import et montage de clips en 9:16 avec cadrage, zoom, captions Whisper et validation manuelle.
- Transcription locale via whisper.cpp, avec timestamps mot à mot DTW lorsque le binaire compatible est installé.
- Détection des moments forts depuis un fichier vidéo local ou une URL Twitch de VOD/clip.
- Analyse VOD par plage horaire (3 heures maximum par analyse), classement audio/texte et création d'un Short depuis un passage sélectionné.
- Mises à jour via les GitHub Releases publiques du dépôt `Sreleew/GTA_rankd`.

## Détection des moments forts v0.4.0

La première version classe les passages avec l'énergie audio, la densité de transcription Whisper et des mots de réaction. Il s'agit d'une heuristique transparente, pas d'une compréhension visuelle du gameplay ni d'une garantie qu'un passage sera divertissant. La détection visuelle et un classement par IA seront des étapes ultérieures.

Les fichiers vidéo, l'audio, les modèles, les bases de données et les projets restent locaux. Aucun média n'est envoyé dans le cloud. Les VOD Twitch privées ou réservées aux abonnés peuvent ne pas être accessibles par URL ; importe un fichier local auquel tu as accès.

## Développement et tests

```powershell
Copy-Item config.yaml.default config.yaml
python -m pytest -q
```

Les paquets de mise à jour sont construits par `installer/build_release_package.py`. Le workflow GitHub Actions teste le snapshot source, construit le ZIP Windows et publie le ZIP ainsi que `SHA256SUMS.txt` dans une Release stable.

Ne jamais publier `config.yaml`, les vidéos, les bases de données, les modèles IA, `.venv` ou des secrets dans le dépôt.
