# Mises à jour GTA Ranked Studio

## Côté utilisateur

Dans GTA Ranked Studio, ouvrir **Paramètres > Mises à jour**, cliquer sur **Rechercher une mise à jour**, puis sur **Télécharger et installer** si une version est proposée. L'application se ferme et se relance après installation.

La première installation d'une version qui contient le système d'update (v0.3.4) est une mise à jour de transition depuis v0.3.3.3 : l'ancien fichier `UPDATE-FROM-ARCHIVE.bat` reste nécessaire une seule dernière fois. Après cette transition, plus besoin d'extraire des ZIP manuellement.

## Côté publication

Le dépôt public `Sreleew/GTA_rankd` est la source des releases stables.

1. Synchroniser `VERSION.txt`, `pyproject.toml` et le fichier `NOTES-vX.Y.Z.txt`.
2. Commit/push les modifications sur `main`.
3. Soit pousser un tag `vX.Y.Z`, soit lancer le workflow manuel **Build and publish GTA Ranked Studio** depuis l'onglet Actions.
4. Pour le workflow manuel, saisir le même numéro que `VERSION.txt`.
5. Vérifier que la Release contient :
   - `GTA-Ranked-Studio-vX.Y.Z.zip`
   - `SHA256SUMS.txt`

Le paquet est généré par `installer/build_release_package.py`. Le script exclut les environnements virtuels, les vidéos, les rendus, les bases de données, les journaux et les modèles/outils locaux.

## Sécurité et intégrité

- Le client ne contacte que l'API GitHub de ce dépôt et des URL d'assets de Releases GitHub en HTTPS.
- Le client vérifie la somme SHA-256 avant installation.
- Le ZIP est testé avant extraction.
- L'installateur n'écrase pas `config.yaml` ni les données personnelles.
- Les dossiers `studio`, `installer` et `tests` sont sauvegardés sous `work/updates/rollback-*`.
- L'installation est restaurée si une erreur survient pendant le remplacement.
- La mise à jour est lancée hors du processus de l'application, puis l'application redémarre.

## Limites connues de v0.3.4

Le téléchargement, le hash et la structure du ZIP sont vérifiés. Le script d'installation PowerShell doit encore être validé sur Windows réel, car le pipeline de test exécuté dans un environnement non-Windows ne peut pas simuler le verrouillage de processus et le redémarrage Windows.


## v0.3.5 : Whisper DTW

Le diagnostic exige les options `-dtw`, `-ojf` et `-nfa`. Le traitement ajoute `-nfa` pour désactiver Flash Attention et laisser whisper.cpp calculer les timestamps DTW. La validation finale consiste à confirmer des valeurs `t_dtw` non négatives sur les tokens parlés.


## v0.3.6 : journalisation de l’updater

Le journal `last-update.log` est initialisé avant le lancement PowerShell et `powershell-output.log` capture sa sortie console. Si PowerShell échoue immédiatement, le serveur GTA Ranked Studio reste actif et l’erreur est affichée dans l’interface. L’installateur utilise des tableaux simples compatibles Windows PowerShell 5.1 et écrit sa progression dans le journal.


## v0.4.0 : Moments forts

La page Moments forts ajoute l'analyse locale de fichiers vidéo et de VOD/clips Twitch. Les VOD peuvent être limitées à une plage de 3 heures maximum. L'analyse combine énergie audio, densité de transcription Whisper et mots de réaction pour proposer jusqu'à huit passages de 35 secondes. Le candidat sélectionné est envoyé au pipeline Shorts existant via un découpage `source_range`.

La première version n'analyse pas encore l'image et ne prétend pas comprendre la scène du jeu. Les scores classent des signaux audio/texte et doivent être validés par l'utilisateur.

        
## v0.4.1 : analyse des VOD longues

L'inspection FFprobe après téléchargement Twitch utilise maintenant un délai calculé selon la taille du fichier (minimum 5 minutes, maximum 30 minutes). La progression distingue l'inspection vidéo de l'analyse audio. Les autres traitements Shorts conservent leur délai FFprobe par défaut.

        
## v0.4.2 : découpage réel des VOD Twitch

Le téléchargement de plages horaires Twitch utilise l'option Python download_ranges de yt-dlp. Les horaires de début et de fin sont donc appliqués au fichier téléchargé, plutôt que seulement conservés dans les métadonnées du scan. La limite de 3 heures par analyse et le correctif FFprobe v0.4.1 sont conservés.


## v0.5.0 : moments forts adaptatifs et webcam

Le scan compare plusieurs durées de passages, de 25 à 60 secondes, puis sélectionne les candidats les mieux classés sans chevauchement. Lors de l'analyse, tu peux indiquer dans quel coin de la VOD se trouve la webcam. Cette zone est ensuite extraite et superposée au gameplay dans le rendu vertical. Les processus externes utilisés sous Windows ne créent plus de fenêtres console parasites ; leurs sorties restent consignées dans les logs.


## v0.5.1 : rendu vertical sans recadrage

Le rendu par défaut conserve l'image source entière, centrée dans le format 9:16, avec une copie agrandie et floutée en arrière-plan. Le zoom dynamique est désactivé par défaut. La webcam incrustée dans la VOD reste visible dans l'image complète ; le logiciel ne l'extrait plus séparément.


## v0.6.0 : diarisation, hooks et téléchargements

Le mode « Voix dominante uniquement (bêta) » identifie les intervenants sur l'audio du Short final et ne conserve les mots de la voix dominante que si l'écart entre locuteurs est suffisamment clair. Le moteur CPU local est installé à la demande ; en cas d'incertitude, toutes les voix restent sous-titrées. Les hooks sont raccourcis et fondés sur la transcription, la carte de contexte est désactivée par défaut, et la génération de métadonnées est limitée à 20 secondes. Les téléchargements Twitch sont limités à 1080p avec davantage de fragments concurrents et de tentatives. Les téléchargements du modèle Whisper reprennent les fichiers partiels lorsque le serveur accepte HTTP Range.


## v0.6.1 : finition du formulaire de voix

Correction mineure de l'espacement du sélecteur « Voix à sous-titrer ». Aucun changement fonctionnel sur la diarisation ou le rendu.


## v0.6.2 : sélection stricte des moments forts

La détection ne s'arrête plus à huit candidats. GTA Ranked Studio conserve tous les passages distincts dont le score est strictement supérieur à 80/100 et masque les autres. Le classement par score et l'espacement entre passages restent actifs. Le score demeure une heuristique locale basée sur l'énergie audio, la densité de parole et les mots de réaction ; il ne comprend pas encore les événements visuels du gameplay.


## v0.7.0 : social publishing kit et annulation des traitements

GTA Ranked Studio génère désormais des titres, descriptions et hashtags spécifiques à YouTube Shorts, TikTok et Instagram Reels. Un seul appel Ollama local est limité à 8 secondes et un fallback déterministe garantit la disponibilité des exports. Chaque Short est accompagné de trois fichiers texte prêts à copier/coller. La miniature utilise une image réelle du clip et une direction artistique originale GTA Ranked, sans génération d'image distante. Les traitements Shorts et Moments forts peuvent être annulés depuis leur carte ; FFmpeg et Whisper sont interrompus proprement.


## v0.7.1 : miniatures GTA et texte social plus naturel

Les miniatures sont désormais créées à partir d'une vraie image de la vidéo source au moment fort, puis composées en poster vertical 1080x1920 avec une identité GTA Ranked plus forte et sans les grands espaces vides du Short vertical. Le titre et la légende sont unifiés pour YouTube Shorts, TikTok et Instagram Reels ; un seul bouton copie l'ensemble du post. La génération locale reste limitée à un appel Ollama et huit secondes maximum, avec fallback instantané.
